# Marketing OS — Consolidated Claude Context
**v1.3 · 2026-04-07 · Upload this file to Claude.ai Project Knowledge**

---

# Marketing OS — CLAUDE.md
**Version:** 1.3 | **Date:** 2026-04-07
**Architecture:** Brain + Orchestrator | **Execution:** ChatGPT GPTs (cheaper, web-browsing enabled)
**Changelog:** v1.3 — Claude is strategy/brief/evaluation only. ChatGPT executes all content generation.

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    CLAUDE  (Brain)                          │
│  • Holds project context      • Generates execution briefs  │
│  • Makes routing decisions    • Evaluates returned output   │
│  • Runs strategy sessions     • Tracks token budget         │
└──────────────────────────┬──────────────────────────────────┘
                           │  Brief → Denis copies to ChatGPT
                           ▼
┌─────────────────────────────────────────────────────────────┐
│                   CHATGPT GPTs  (Execution)                 │
│  • ICP Builder (web research)  • Content Builder (emails)   │
│  • Messaging Builder           • Landing Builder            │
│  • Funnel Builder              • Build Planner              │
└─────────────────────────────────────────────────────────────┘
                           │  Output → Denis pastes back to Claude
                           ▼
                    Claude evaluates (7+/10?)
                    ↓ Pass → Ship  |  Fail → Revision brief
```

**Why this split:**
- Claude: strategic depth, context retention, quality judgment — but costs tokens
- ChatGPT: flat-rate pricing, web browsing, high-volume content generation — cheap at scale
- Denis: talks to Claude for direction, takes to ChatGPT for execution, returns for eval

---

## Claude's Role — What Claude Does and Does NOT Do

### ✅ Claude DOES:
- Load and maintain project-marketing-context.md per project
- Understand Denis's request and route to the right ChatGPT GPT
- Generate a structured execution brief for that GPT
- Evaluate output Denis brings back (score 1–10, flag issues)
- Write revision briefs when output scores below 7/10
- Run strategy sessions (ICP decisions, channel planning, messaging strategy)
- Update project context with learnings from campaigns
- Track token budget across the month

### ❌ Claude does NOT:
- Write cold emails (→ ChatGPT: Content Builder)
- Write landing page copy (→ ChatGPT: Landing Builder)
- Write ad creative (→ ChatGPT: Content Builder)
- Do web research (→ ChatGPT: ICP Builder with web browsing)
- Write blog posts or social content (→ ChatGPT: Content Builder)
- Build funnels or scoring rubrics (→ ChatGPT: Messaging Builder / Funnel Builder)

**Exception:** Denis can ask Claude to do quick one-off tasks (single email, one headline) where the overhead of ChatGPT isn't worth it. Claude uses judgment — flag the token cost and offer the brief alternative.

---

## ── UX LAYER ── Response Format

Every Claude response uses this structure:

```
🧠 [What I understand + which GPT to use]
📋 [Brief for ChatGPT — paste-ready]

[Strategy or evaluation content if applicable]

📊 [Quality score if evaluating returned output]
➡️ Next: [exact action Denis takes]
```

---

## Conversation Starters — Paste Into Project Settings

```
🧠 Plan my next campaign — tell me the goal, I'll build the brief
```
```
📊 Evaluate this output — paste what ChatGPT gave you
```
```
🗺️ Build my strategy — new project or channel decision
```
```
🔄 Update my project context — ICP, messaging, or channel changed
```

**What each triggers:**
| Starter | Claude does | Denis takes to ChatGPT |
|---------|------------|----------------------|
| 🧠 Plan campaign | Loads context, defines goal, produces brief | Brief → right GPT |
| 📊 Evaluate output | Scores 1–10, flags issues, writes revision brief if needed | Revision brief → same GPT |
| 🗺️ Build strategy | Full strategy session: ICP, channels, messaging | Brief → ICP Builder or Messaging Builder |
| 🔄 Update context | Asks what changed, updates project-marketing-context.md | Nothing — context updated |

---

## The Brief — Standard Format

Every brief Claude generates for ChatGPT follows this structure:

```
📋 BRIEF FOR [GPT NAME]
─────────────────────────────────────────
Project: [ProjectName]
ICP: [role + company type + primary pain — 1 sentence]
Goal: [what this piece needs to achieve — specific action/metric]
Format: [cold email / landing page / blog post / ad / etc. + length]

Messaging to hit:
  • [Key message 1 — specific, not generic]
  • [Key message 2]
  • [Key message 3]

Objections to address:
  • [Objection 1 — how to pre-empt]
  • [Objection 2]

Proof points available:
  • [Customer quote / stat / case study Denis has]

Tone: [direct / conversational / authoritative / warm]
Versions needed: [1 / 3 / 5 — and why]

Quality bar: 7+/10 on ICP match, messaging alignment, differentiation, objection handling
─────────────────────────────────────────
Paste this into [GPT Name] to execute.
```

---

## Routing Logic — Which GPT for What

```
Denis asks for:                    → Send to:
─────────────────────────────────────────────────────────
Market research / ICP profile      ICP Builder (use web browsing)
Competitor analysis                ICP Builder (use web browsing)
Customer quotes / forum research   ICP Builder (use web browsing)
Positioning / messaging score      Messaging Builder
Messaging from scratch             Messaging Builder
Cold emails / outbound             Content Builder
Email sequences                    Content Builder
Ad copy                            Content Builder
Blog posts / LinkedIn threads      Content Builder
Newsletter                         Content Builder
Copy editing / rewrites            Content Builder
Full landing page                  Landing Builder
Hero copy / CTA options            Landing Builder
Funnel design / audit              Funnel Builder
Conversion optimization            Funnel Builder
Feature spec / PRD                 Build Planner
Launch plan                        Build Planner
Roadmap prioritization             Build Planner
```

---

## Mode Commands

| Command | Claude does |
|---------|------------|
| `strategy mode` | Deep session: ICP, channels, GTM — no brief, just thinking |
| `brief mode` | Quick brief generation — minimal context needed |
| `evaluate` | Score returned output 1–10, flag issues, write revision brief |
| `update context` | Refresh project-marketing-context.md with learnings |
| `budget check` | Show token usage this month vs. 10–15K target |
| `reset` | Clear active project, return to default |

---

## Quality Evaluation — When Denis Returns ChatGPT Output

Score on 4 dimensions. Write revision brief if below 7/10.

```
📊 Quality Evaluation:

  Q1 ICP Match:         [X]/10 — [one-line reason]
  Q2 Messaging:         [X]/10 — [one-line reason]
  Q3 Differentiation:   [X]/10 — [one-line reason]
  Q4 Objections:        [X]/10 — [one-line reason]
  ─────────────────────────────────────
  Score: [X]/10

  ✅ Ship it (≥7/10)
  OR
  🔄 Revision brief: [specific fix for each dimension below 7]
```

**Revision brief format:**
```
📋 REVISION BRIEF FOR [GPT NAME]
─────────────────────────────────
Here's what to fix in the previous output:

ICP Match (scored [X]/10):
  Problem: [specific issue]
  Fix: [specific instruction — "use this phrase instead" / "add this proof point"]

Messaging (scored [X]/10):
  Problem: [specific issue]
  Fix: [specific instruction]

[Repeat for any dimension below 7]

Keep: [what's working — don't change this]
─────────────────────────────────
Paste this into [GPT Name] with the original output.
```

---

## Token Budget — Claude's New Target

**Architecture shift impact:**
- Old (Claude executes everything): 20–30K tokens/month
- New (Claude = brain only): **8–15K tokens/month**

| Activity | Tokens | Frequency |
|----------|--------|-----------|
| Strategy session (new project) | 3–5K | Once per project |
| Brief generation | 0.5–1K | Per campaign |
| Quality evaluation | 0.5–1K | Per output reviewed |
| Context update | 0.5K | Monthly |
| Quick routing + brief | 0.3–0.5K | Daily use |

**Monthly cadence at 8–15K:**
- Week 1: Strategy session (3–5K) + 3–4 briefs (2–3K) = 5–8K
- Week 2–4: Evaluation + briefs (3–5K)
- Total: ~8–13K — well under budget

**ChatGPT cost:** Flat Plus subscription (~$20/month). No per-token cost. Use as much as needed.

---

## Project Context Management

Load project context at start of every session:
```
[ProjectName]_marketing.md → ICP, messaging pillars, proof points, channels, learnings
```

**Update triggers:**
- After evaluating a campaign that scored below 6/10 (ICP insight)
- After a campaign that performed above 15% reply rate (winning angle)
- When Denis says ICP or positioning has changed
- Monthly review session

**How to update:** Ask Denis: "What changed? ICP, messaging, channels, or all three?" → rewrite only the changed section.

---

## Artifact Mode

Claude uses artifacts for:
- Strategy documents (GTM plan, channel recommendations)
- Project context files (project-marketing-context.md)
- Multi-week campaign plans
- Complete briefs with 3+ GPT tasks

Claude does NOT use artifacts for:
- Single briefs (inline is fine)
- Quick evaluations
- Routing decisions

---

## Workflow Examples

### Example 1: Cold Email Campaign
```
Denis: "I need a cold email campaign for Project A"
Claude: [Loads Project A context]
        "🧠 Routing to Content Builder. Here's your brief:"
        [Generates brief with ICP, messaging, 5-email format, tone]
        "➡️ Paste into Content Builder in ChatGPT"

Denis: [Returns with 5 emails from ChatGPT]
Claude: "📊 Evaluating..." [scores each email]
        "Email 1: 8/10 ✅ | Email 2: 5/10 🔄 — ICP language off"
        [Generates revision brief for Email 2]
        "➡️ Paste revision brief into Content Builder"
```

### Example 2: Market Research (New Project)
```
Denis: "I'm launching a new product for [audience]"
Claude: [Runs strategy session — 3–4K tokens]
        "🧠 Routing to ICP Builder. Here's your research brief:"
        [Generates brief: what to research, where to look online, key questions]
        "➡️ Open ICP Builder in ChatGPT — enable web browsing — paste this"

Denis: [Returns with ICP profile + customer quotes from web research]
Claude: [Evaluates quality]
        "📊 ICP profile looks solid (8/10). One gap: no buying trigger data."
        "➡️ Quick follow-up brief: ask ICP Builder to research buying triggers"
        [After second pass: creates project-marketing-context.md from research]
```

### Example 3: Landing Page
```
Denis: "Build my landing page for [Project]"
Claude: [Loads project context]
        "🧠 Routing to Landing Builder. Brief:"
        [Hero spec, ICP, 7 sections brief, proof points, primary CTA]
        "➡️ Paste into Landing Builder. It will open canvas automatically."

Denis: [Returns with full page from ChatGPT canvas]
Claude: [Evaluates section by section]
        "📊 Hero: 9/10 ✅ | FAQ: 5/10 🔄 — objections too generic"
        [Revision brief for FAQ section]
```

---

## Error States

**If Denis doesn't bring back ChatGPT output:**
> "What did ChatGPT give you? Paste it here and I'll evaluate."

**If Denis wants Claude to execute directly (skip ChatGPT):**
> "⚡ I can do this (~[X]K tokens) but ChatGPT is cheaper for this type of task. Your call — paste brief into Content Builder (free) or I execute now (costs tokens)?"

**If output keeps scoring below 7/10 after 2 revisions:**
> "The brief might need to be rebuilt from scratch. Something in the project context is off. Let's revisit the ICP — 5 min strategy session?"

---

## Reference Docs

- **MARKETING_OS_SkillOrchestration_Matrix_v1.0.md** — legacy skill map (reference for strategy sessions)
- **MARKETING_OS_Instructions_v1.0.md** — behavioral rules
- **MARKETING_OS_KnowledgeStructure_v1.0.md** — templates
- **MARKETING_OS_SetupGuide_v1.2.md** — setup + workflow
- **MARKETING_OS_tasks_v1.0.md** — backlog

---

## One-Liner

"🧠 Understand → 📋 Brief → ChatGPT executes → 📊 Evaluate → ✅ Ship or 🔄 Revise"

---

*Marketing OS v1.3 · CLAUDE.md · 2026-04-07*
*Architecture: Claude = brain/evaluator. ChatGPT = execution engine. Lean, cheap, high-output.*


---


# Marketing OS — Knowledge Structure
**Version:** 1.0 | **Date:** 2026-04-07 | **Purpose:** Reusable templates and libraries shared across all projects

---

## Overview

This document contains **templates and libraries** that are project-agnostic. Once created, they apply to ALL projects. Reference these when building campaigns, writing copy, and designing flows.

---

## Library 1: Customer Language Patterns

**Use these phrases when you encounter them in customer interviews. These will work for ANY ICP.**

### Pain Point Language Patterns
- "It's [specific time]—wasting hours on [task]"
- "We can't [specific capability]—it's killing us"
- "Everyone tells us we should [outcome], but we're stuck on [blocker]"
- "[Person/Team] is frustrated because [pain]"
- "This costs us $[amount]/month in lost [metric]"
- "We've tried [solution], but it didn't [desired outcome]"

### Desire Language Patterns
- "What we really want is [outcome] in [timeframe]"
- "If we could just [action], we'd [result]"
- "I'd pay for something that [specific capability]"
- "We're looking for [outcome], not [alternative]"

### Objection Language Patterns
- "Our team is worried about [concern]"
- "We've been burned by [similar solution]"
- "It's too [attribute] for us"
- "We don't have [resource] to implement this"

### Buying Signal Language Patterns
- "We're currently evaluating [category]"
- "We need to solve [problem] by [date]"
- "The board is pushing us to [outcome]"
- "Budget is approved if we can [condition]"

---

## Library 2: Message Pillar Templates

**These are generic pillar templates. Customize them per project.**

### Pillar 1: Problem Validation (Problem Statement + Proof)
**Template:**
```
"[ICP Role] at [Company Type] spend [X hours/days] on [Task],
costing $[Amount] in lost [Metric].

But it doesn't have to be this way."
```

**Example:**
```
"VP Marketing at mid-market SaaS spends 15 hours/week on reporting,
costing $15,000/month in lost strategic work.

But it doesn't have to be this way."
```

---

### Pillar 2: Unique Solution (Your Approach)
**Template:**
```
"Unlike [competitor approach], [Your Company] [Unique Action] by [Method].
This means [Outcome] without [Pain/Cost/Friction]."
```

**Example:**
```
"Unlike manual reporting dashboards, Mercury automates compliance
by integrating with your existing stack. This means clean, accurate
reports without learning new software."
```

---

### Pillar 3: Credibility & Trust (Proof)
**Template:**
```
"[Number] [Group] trust [Your Company] to [Outcome].
[Specific Case Study / Stat / Credential]."
```

**Example:**
```
"500+ mid-market teams trust Mercury to save 15 hours/week.
Brex, Notion, and Mercury Customers (case studies available)."
```

---

### Pillar 4: Desired Outcome (Their Version of Success)
**Template:**
```
"Imagine: [Time/Resource Freed Up] + [Capability Gained].
[Emotional payoff or business impact]."
```

**Example:**
```
"Imagine: 15 hours/week reclaimed + confidence in accuracy.
Your marketing team focuses on strategy instead of admin."
```

---

### Pillar 5: Movement / Social Proof (Trend or Community)
**Template:**
```
"[Number] [Group] are already [Action].
[Specific example or statistic about the movement]."
```

**Example:**
```
"500+ founders are already automating compliance with Mercury.
Join the movement to reclaim your time."
```

---

## Library 3: Cold Email Templates

### Structure (Proven to Work)
```
Subject: [Personalized, specific to their role/company]

Opening Hook: [Specific observation about their company or role]

Problem Recognition: [State their problem in their language]

Pivot: But here's what we've seen work...

Solution: [How your approach solves it]

Proof: [Case study / stat / social proof]

CTA: [Specific, low-friction ask]

Signature: [Name, title, LinkedIn, maybe one credential]
```

### Email Template 1: Problem Recognition Angle
```
Hi [Name],

[Specific observation]: I noticed [Company] is [specific action/signal that shows they have the problem].

Most [Role] at [Company Size] are stuck [Problem Statement].

What we've seen work: [Unique approach].

This helped [Case Study: Role/Company] [Specific Outcome] in [Timeframe].

Curious if this could work for [Company]?

[CTA: Low friction — "Chat briefly?"]

[Signature]
```

### Email Template 2: Credibility Angle
```
Hi [Name],

I work with [Number] [Role] at [Company Type].

Most are struggling with [Problem].

Here's what's changed: [Why now / What's different].

[Case Study: Problem → Solution → Outcome]

Wondering if [Company] is dealing with [Specific Problem]?

[CTA: "Quick call?"]

[Signature]
```

### Email Template 3: Differentiation Angle
```
Hi [Name],

[Specific research point]: You mentioned [specific thing they said/wrote].

Most [Role] who want [Outcome] try [Competitor Approach].

But we've found [Your Unique Angle] works better because [Reason].

[Proof: Stat or Case Study]

Worth a conversation?

[CTA]

[Signature]
```

### Follow-Up Templates
**Follow-Up 1 (2 days later):**
```
[Name] — Quick follow-up from my note above.

[Restate value + new angle]

[CTA: Lower friction — "Free consultation?"]
```

**Follow-Up 2 (4 days later):**
```
[Name] — One more thing:

[Different angle / proof / case study]

[CTA: "Let's chat"]
```

**Follow-Up 3 (1 week later):**
```
[Name] — Last note:

I know most of you are busy. But if [Outcome] is even remotely on your radar this quarter, this is worth 15 minutes.

[CTA: Direct calendar link]
```

---

## Library 4: Landing Page Copy Templates

### Sales Page Structure
```
HERO (Above the fold):
- Headline: [Outcome-focused, not feature]
- Subheadline: [Specific problem solved]
- Hero Image/Video: [Proof of transformation or product in action]
- CTA: [Primary action — clear, specific]

SECTION 2: Problem Validation
- [Specific statistic or customer quote about the problem]
- Pain points (3–5 bullets)
- Why it matters [emotional or business impact]

SECTION 3: Unique Solution
- How you solve it differently
- 3–5 unique capabilities (not features)
- Why that difference matters

SECTION 4: How It Works
- Step-by-step: From signup to outcome
- 3–5 steps, each showing transformation

SECTION 5: Social Proof
- Customer testimonials (3–5)
- Case study (before/after)
- Numbers (customers, impact, growth)
- Logos of known companies

SECTION 6: Objection Handling
- FAQ addressing common objections
- Pricing/affordability addressed
- Switching cost / implementation concern addressed
- "Why us vs. alternatives" comparison

SECTION 7: Limited Offer / Urgency
- Free trial / demo / consultation
- Limited time / spots
- Clear CTA + calendar link

SECTION 8: Final CTA
- Reiterate transformation
- Reminder of proof
- Call to action
```

---

## Library 5: Email Sequence Templates

### Nurture Sequence Structure (5–10 Emails)

**Email 1 (Immediately):** Welcome + What to Expect
```
Subject: Welcome to [Resource/Community]

Content:
- Thank you for subscribing
- What they'll get (value promise)
- First email coming tomorrow
- [Soft CTA: Forward to a friend]
```

**Email 2 (Day 2):** Problem Recognition + Story
```
Subject: The [Problem] problem most [Role] have

Content:
- Customer story: How [Customer] faced [Problem]
- Why this problem is widespread
- One insight they can apply today
- [Soft CTA: Reply with your biggest challenge]
```

**Email 3 (Day 4):** Solution Mechanism
```
Subject: How [Company] solved [Problem]

Content:
- Explain your unique approach
- Why this approach works (mechanism)
- Case study or proof
- [CTA: Free resource / guide / audit]
```

**Email 4 (Day 7):** Objection Handling
```
Subject: Doubt? Here's why others were skeptical too...

Content:
- Common objection: [Common doubt]
- Why that doubt is valid
- How you address it
- Customer proof that doubt was unfounded
- [CTA: Free trial / demo]
```

**Email 5 (Day 10):** Limited Offer / Urgency
```
Subject: [Limited offer] — ending [date]

Content:
- Specific offer (discount, bonus, limited spots)
- What's included
- Why now (scarcity / deadline)
- [CTA: Claim offer]
```

---

## Library 6: Ad Creative Templates

### Cold Prospecting Ad (LinkedIn)
```
Headline: [Benefit-focused, not feature]
Primary Image: [Customer testimonial / proof / transformation]
Copy:
"[Problem statement most [ICP] face]

What most don't realize: [Unique insight]

[Company] helps [ICP] [Specific outcome] by [Unique approach].

[Proof or stat]

Try free for [timeframe]: [Link]"

CTA: Download Guide / Try Free / Book Demo
```

### Remarketing Ad (Website Visitors)
```
Headline: "Come back. Here's what you missed."
Copy: "[Customer name], you visited us on [Date].

[Problem you were likely exploring]

We've helped [Number] [ICP] [Specific outcome].

Let's talk about [specific problem they came for]."

CTA: "Schedule Demo" / "See Case Study"
```

### Brand Awareness Ad (New Audience)
```
Headline: "[Outcome] without [Pain/Cost]"
Copy: "[Problem statement]

But [Company] changes that with [Unique approach].

[Customer proof]

[Company] is trusted by [Number] [Group].

[CTA]"
```

---

## Library 7: Positioning Statements (By Use Case)

### For B2B SaaS (Mid-Market)
```
"For [VP Title] at [Company Size], [Product] is the [Category] that
[Specific outcome] because [Reason], unlike [Competitor approach]."

Example:
"For VP Marketing at $20–100M SaaS, Mercury is the compliance platform
that automates audits in 3 clicks because founders need to focus on
growth, unlike manual audit workflows."
```

### For Enterprise
```
"For [CxO] responsible for [Function], [Product] is the [Category]
that [Measurable outcome] while [Important constraint], unlike [Alternative]."

Example:
"For CISO managing security compliance, CloudGuard is the platform
that reduces audit prep from 6 weeks to 2 days while maintaining
SOC 2 standards, unlike point solutions."
```

### For Outbound/Marketplace
```
"For [Target Audience] looking for [Outcome], [Company] is the
[Unique angle] because [Proof/Difference]."

Example:
"For freelance designers looking for steady client work, OnlyProjects
is the platform where clients come to you (not the reverse) because
we focus on quality over volume."
```

---

## Library 8: Customer Research Questions (Reusable)

### Discovery Interview Questions
1. "What's your biggest challenge with [Topic]?"
2. "How does that impact your work/business?"
3. "How do you currently solve this?"
4. "What doesn't work about your current approach?"
5. "If you could change one thing, what would it be?"
6. "What outcomes matter most to you?"
7. "Who else influences this decision?"
8. "What's your budget for solutions like this?"
9. "What would make you switch from [current solution]?"
10. "What does success look like 6 months from now?"

### Win/Loss Analysis Questions
**If they bought:**
1. "What was the deciding factor?"
2. "What almost stopped you?"
3. "What could we have done differently?"

**If they didn't:**
1. "What was the main reason?"
2. "Did you choose a competitor? Which one?"
3. "What could we have done to win?"

---

## Library 9: Metrics & Success Thresholds

| Channel/Tactic | Industry Baseline | Excellent | Your Target |
|---|---|---|---|
| Cold Email | 2–3% reply rate | 8–10% | ___ |
| Content (Blog) | 0.5–2% conversion | 5%+ | ___ |
| Landing Page | 2–5% conversion | 10%+ | ___ |
| Paid Ads (LinkedIn) | 1–2% CTR | 3%+ CTR | ___ |
| Email Sequence | 20–30% engagement | 50%+ engagement | ___ |
| Sales Demo | 20–40% qualified | 50%+ close rate | ___ |

---

## Library 10: Objection Response Framework

| Objection | Root Cause | Response Framework |
|---|---|---|
| "It's too expensive" | Price sensitivity | [Total Cost of Ownership] vs. [alternative cost]. ROI calculation. |
| "We're not ready" | Timing concern | [Trigger that makes them ready] is [Timeframe]. Let's plan. |
| "We tried something similar" | Bad past experience | [Competitor difference]. [Proof it works better]. |
| "Our team doesn't have time" | Implementation concern | [Setup time]. [Implementation support included]. |
| "We need to think about it" | Not convinced | [Specific outcome they'd gain]. [Proof from peer company]. |
| "Let me check with my team" | Not the decision-maker | [Decision-maker title]. [How to involve them]. |

---

## How to Use These Libraries

**When creating copy:**
1. Pick the relevant template (landing page, email, cold email)
2. Customize it for YOUR project's ICP and messaging
3. Reference the customer language library for authentic phrasing
4. Test using ab-test-setup skill

**When stuck:**
1. Reference the pattern library (message pillars, positioning statements)
2. See examples
3. Adapt to your specific ICP

**When evaluating:**
1. Use the metrics library for success thresholds
2. Compare your output to baseline
3. Decide: Excellent, Good, or Needs Revision

---

*Marketing OS v1.0 · Knowledge Structure · 2026-04-07*
*Reusable across all projects. Customize per project context.*


---


# [PROJECT NAME] — Marketing Context
**Version:** 1.0
**Date:** YYYY-MM-DD
**Project:** [Project/Client Name]
**Created by:** Denis
**Status:** [Draft / Active / Archived]

---

## Quick Reference

**ICP:** [1 sentence description of ideal customer]
**Positioning:** [1 sentence positioning statement]
**Primary Channels:** [Tier 1 channels, max 3]
**GTM Phase:** [Research / Launch / Scaling / Optimizing]

---

## Section 1: ICP (Ideal Customer Profile)

### Company Profile
- **Industry:** [Which vertical? SaaS, B2B, D2C, Enterprise, etc.]
- **Company Size:** [# employees, revenue range, growth stage]
- **Geography:** [Target regions: US, EU, APAC, Global?]
- **Business Model:** [Subscription, one-time, service-based, marketplace?]
- **Revenue Model:** [How do THEY make money?]

### Buyer Role & Responsibility
- **Primary Buyer Title:** [CEO, VP Marketing, Marketing Manager, IC developer, etc.]
- **Secondary Influences:** [Who else influences the decision?]
- **Budget Authority:** [Does this person control spend? How much?]
- **Success Metric (Their's):** [What does winning look like for them?]
- **Reporting Structure:** [Do they have a team? How big?]

### Pain Points (Use Customer Quotes)
1. **Primary Pain:** [Top problem] — Quote: *"[customer language]"*
2. **Secondary Pain:** [Related problem] — Quote: *"[customer language]"*
3. **Tertiary Pain:** [Underlying problem] — Quote: *"[customer language]"*

### Motivations & Desired Outcome
- **Core Desire:** [What outcome do they want?]
- **Buying Trigger:** [What event makes them start looking?]
- **Timeline:** [How urgent is this problem?]
- **Constraints:** [Budget caps, technical requirements, political blockers?]

### Buying Behavior
- **Buying Cycle:** [How long from awareness to decision? Days, weeks, months?]
- **Decision Process:** [Self-serve, demo, committee, procurement?]
- **Deal Size:** [Average contract value for solutions like yours?]
- **Common Objections:** [What stops them from buying?]
  - Objection 1: [and how we address it]
  - Objection 2: [and how we address it]
  - Objection 3: [and how we address it]

### Channel Affinity
- **Primary Digital Channels:** [Twitter, LinkedIn, Reddit, Slack communities, industry forums?]
- **Content Format Preference:** [Blogs, videos, newsletters, podcasts, whitepapers, case studies?]
- **Sales Preference:** [Self-serve, freemium, demos, cold calls, partner referrals?]
- **Information Sources:** [Where do they research solutions? G2, Reddit, peer recommendations, analyst reports?]

---

## Section 2: Positioning & Messaging

### Positioning Statement (One Sentence)
*"For [ICP], [Product] is the [Category] that [Unique Value] because [Reason]."*

Example: *"For early-stage founders, Mercury is the business banking platform that handles compliance automatically because founders hate dealing with traditional banks."*

**Your positioning:**
[Insert here]

---

### Key Message Pillars (Max 5)

#### Pillar 1: Problem Validation
- **Message:** [State the problem in customer language, not features]
- **Proof:** [Data, customer quote, stat from research]
- **Why It Matters:** [Connection to their success metric]

#### Pillar 2: Unique Solution
- **Message:** [What's different about your approach?]
- **Proof:** [Competitive differentiation, customer testimonial]
- **Why It Matters:** [Specific outcome they get]

#### Pillar 3: Credibility & Trust
- **Message:** [Why should they believe you?]
- **Proof:** [Case study, customer count, years in market, team creds]
- **Why It Matters:** [Risk reduction]

#### Pillar 4: Desired Outcome
- **Message:** [What's the payoff? What changes for them?]
- **Proof:** [Customer success story, metric improvement]
- **Why It Matters:** [Their version of success]

#### Pillar 5: Social Proof / Movement
- **Message:** [Why are others choosing this? What's the trend?]
- **Proof:** [Case studies, testimonials, community size]
- **Why It Matters:** [FOMO, validation, credibility]

---

### Customer Language Library

**Use these phrases verbatim in copy, emails, ads:**

Pain Point Language (from customer interviews):
- [Quote 1: "[customer pain point in their words]"]
- [Quote 2: "[customer pain point in their words]"]
- [Quote 3: "[customer pain point in their words]"]

Desire Language (what they want):
- [Quote 1: "[desired outcome in their words]"]
- [Quote 2: "[desired outcome in their words]"]

Objection Language (common blockers):
- [Objection 1: "[how they phrase resistance]"]
- [Objection 2: "[how they phrase resistance]"]

---

## Section 3: Brand & Story

### Origin Story
*Why did you start this? What problem motivated you?*

[Your answer, 1–2 paragraphs. Use this in long-form content, landing pages, and about pages.]

---

### Brand Values
*What do you stand for? (Not fluffy, be specific)*

1. [Value 1]: [Why it matters, specific example]
2. [Value 2]: [Why it matters, specific example]
3. [Value 3]: [Why it matters, specific example]

---

### Brand Voice & Personality

- **Tone:** [Casual, formal, technical, playful, irreverent, authoritative?]
- **Vocabulary:** [Jargon level — technical deep-dive or plain English?]
- **Sentence Length:** [Short and punchy, or detailed and thorough?]
- **Humor:** [Funny, dry, none?]
- **Example Phrase:** [How would you describe your product in one sentence, in your voice?]

---

### Narrative Arc (Customer Journey)

**BEFORE:** *[Customer's current situation, pain, frustration]*
> Example: "Most founders spend 30% of their time on operations instead of building."

**MOMENT:** *[The realization or trigger that changes things]*
> Example: "We watched a great product die because operations overhead killed momentum."

**AFTER:** *[New possibility opened up]*
> Example: "What if founders could reclaim that 30% and focus on what matters?"

**MOVEMENT:** *[Invitation to join]*
> Example: "500+ teams have already reclaimed their time. Join the ops revolution."

---

## Section 4: Competitive Positioning

### Direct Competitors
- **Competitor 1:** [Name]
  - Positioning: [How do they position?]
  - ICP: [Who do they target?]
  - Strength: [What are they good at?]
  - Weakness: [Where are they vulnerable?]

- **Competitor 2:** [Name]
  - Positioning: [How do they position?]
  - ICP: [Who do they target?]
  - Strength: [What are they good at?]
  - Weakness: [Where are they vulnerable?]

### Positioning Gaps (Where You Win)
- **Gap 1:** [They don't talk about X, but our ICP cares about X]
- **Gap 2:** [They focus on feature Y, but our ICP cares about outcome Z]
- **Gap 3:** [They target big enterprise, but our ICP is SMB]

### Competitive Advantage
*What can you uniquely claim that competitors can't (or won't)?*
- [Unique claim 1 + proof]
- [Unique claim 2 + proof]

---

## Section 5: Go-To-Market (GTM) Strategy

### Awareness Phase (Weeks 1–4)
**Goal:** Get your ICP to know you exist.

**Primary Channels:**
1. [Channel]: [Tactic — e.g., "Cold email outreach to [title] at [company size]"]
2. [Channel]: [Tactic — e.g., "Content on [topic] targeting [keyword]"]
3. [Channel]: [Tactic — e.g., "Paid ads to [audience]"]

**Budget Allocation:** [%]
**Key Metrics:** [impressions, reach, website traffic, opens]
**Success Threshold:** [e.g., "500 impressions, 50 visits, 10 opens"]

---

### Consideration Phase (Weeks 5–8)
**Goal:** Help them evaluate if you're a fit.

**Primary Tactics:**
1. [Tactic]: [e.g., "Email sequence: problem → solution → proof → CTA"]
2. [Tactic]: [e.g., "Case study on [specific use case]"]
3. [Tactic]: [e.g., "Demo video or product walkthrough"]

**Budget Allocation:** [%]
**Key Metrics:** [engagement rate, click rate, demo requests]
**Success Threshold:** [e.g., "30% email engagement, 5 demo requests"]

---

### Decision Phase (Weeks 9+)
**Goal:** Convert consideration to decision.

**Primary Tactics:**
1. [Tactic]: [e.g., "Sales call with [offer]"]
2. [Tactic]: [e.g., "Free trial with [incentive]"]
3. [Tactic]: [e.g., "Pricing + packaging strategy"]

**Budget Allocation:** [%]
**Key Metrics:** [conversion rate, trial start rate, sales]
**Success Threshold:** [e.g., "5% conversion, 10 trials, 2 sales"]

---

### Post-Launch (Ongoing)
**Retention Tactics:** [How will you keep them happy?]
**Expansion Tactics:** [How will you grow their spend?]
**Feedback Loop:** [How will you learn and improve?]

---

## Section 6: Campaign Calendar

### Q1 Campaign
- **Campaign Name:** [e.g., "Cold Email Blitz"]
- **Timeline:** [Dates]
- **Channels:** [Primary channels for this campaign]
- **Target Audience:** [Specific segment]
- **Messaging Focus:** [Which pillar(s)?]
- **Success Metrics:** [KPIs]
- **Expected Spend:** [$]

### Q2 Campaign
[Repeat above]

---

## Section 7: Metrics & Reporting

### North Star Metric
[What's the one number that matters most? e.g., "Monthly Recurring Revenue" or "Active Users"]

### Supporting Metrics
| Metric | Current | Target (90 days) | Target (6 months) |
|--------|---------|-------------------|-------------------|
| [Awareness metric] | [baseline] | [goal] | [goal] |
| [Engagement metric] | [baseline] | [goal] | [goal] |
| [Conversion metric] | [baseline] | [goal] | [goal] |
| [Retention metric] | [baseline] | [goal] | [goal] |

### Reporting Cadence
- Weekly: [Which metrics? who sees them?]
- Monthly: [Review and iterate?]
- Quarterly: [Deep dive + strategy adjust?]

---

## Section 8: Assumptions & Risks

### Key Assumptions (Mark with [ASSUMED] or [INFERRED])
- [ASSUMED] ICP has budget of [amount] for solutions like ours
- [INFERRED] Cold email will generate 3–5% reply rate based on [data]
- [NEEDS INPUT] Competitor analysis — need to verify [X]

### Known Risks
- **Risk 1:** [Risk description] → Mitigation: [How will you handle it?]
- **Risk 2:** [Risk description] → Mitigation: [How will you handle it?]

---

## Section 9: Document History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | YYYY-MM-DD | Initial context created |
| 1.1 | YYYY-MM-DD | [Updated ICP based on research] |
| 2.0 | YYYY-MM-DD | [Major pivot in positioning] |

---

## How This Doc Is Used

**This file is loaded by:**
- CLAUDE.md (detects active project)
- All 25+ marketing skills (reference ICP, messaging, channels)
- All execution docs (copywriting, emails, ads pull from messaging pillars)
- Evaluation framework (measures success against defined metrics)

**Update this doc when:**
- You conduct new customer research
- Competitive landscape shifts
- Messaging isn't resonating
- Campaign results suggest ICP changes
- New channel opportunity emerges

**Never:**
- Use outdated context (always check version + date)
- Assume context from previous project applies (each project gets its own file)
- Proceed to execution without confirming this doc is complete and current

---

*Marketing OS v1.0 · Project Context Template · 2026-04-07*
*Template for use by Denis across all marketing projects*
