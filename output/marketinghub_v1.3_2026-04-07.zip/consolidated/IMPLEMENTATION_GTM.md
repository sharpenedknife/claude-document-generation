# Marketing Hub — Implementation & GTM Reference
**v1.3 · 2026-04-07 · Full setup + strategy reference**

---

# Marketing Hub — Setup Guide
**Version:** 1.2 | **Date:** 2026-04-07 | **Status:** Production
**Architecture:** Claude = Brain | ChatGPT = Execution Engine

---

## What You're Building

A two-platform marketing system where Claude.ai handles strategy and coordination, and ChatGPT handles all content generation and research. You get the strategic intelligence of Claude at low token cost + the execution throughput of ChatGPT at a flat monthly rate.

```
DAILY WORKFLOW

Denis
  │
  ▼
Claude.ai Project (Marketing OS)
  │  Strategy · Context · Brief Generation · Quality Evaluation
  │
  ├─ generates "📋 BRIEF FOR [GPT]"
  │
  ▼
ChatGPT GPT (ICP Builder / Content Builder / etc.)
  │  Executes brief · Writes content · Pulls web data
  │
  ├─ returns output to Denis
  │
  ▼
Denis pastes output back into Claude
  │
  ▼
Claude evaluates · scores 1–10 · writes revision brief if <7
```

**Token cost:** Claude ~8–15K tokens/month (brain only) | ChatGPT: flat ~$20/month (execution)

---

## PART 1 — CLAUDE.AI SETUP

### Step 1: Create the Project

1. Go to **claude.ai → Projects → New Project**
2. Name: `Marketing OS`
3. Description: `Marketing brain — strategy, briefs, evaluation`

### Step 2: Upload Project Knowledge Files

Upload these files to **Project Knowledge** (drag & drop all at once):

```
CONTEXT_Product.md         ← Your product context
CONTEXT_Technical.md       ← Stack + integrations  
IMPLEMENTATION.md          ← GTM strategy
MARKETING_OS_CLAUDE_v1.3_2026-04-07.md   ← Claude's instructions
```

> **How to upload:** Project → Knowledge → Add content → Upload files

### Step 3: Set Custom Instructions

Go to **Project → Settings → Custom Instructions**. Paste:

```
You are Marketing OS — the strategic brain of Denis's marketing system.

YOUR ROLE:
- Maintain full product/ICP/campaign context
- Generate structured briefs for ChatGPT execution GPTs
- Evaluate returned outputs and score 1–10
- Route requests to the correct ChatGPT GPT
- Never write final marketing copy yourself — generate briefs for ChatGPT

ROUTING:
- ICP research → Brief for ICP Builder
- Positioning / copy scoring → Brief for Messaging Builder  
- Funnel design / conversion → Brief for Funnel Builder
- Emails / ads / blog / social → Brief for Content Builder
- Feature specs / launch plans → Brief for Build Planner
- Landing pages → Brief for Landing Builder

BRIEF FORMAT (always use this structure):
📋 BRIEF FOR [GPT NAME]
Project: [name] | ICP: [description] | Goal: [what to produce]
[GPT-specific fields]
Tone: [direct/warm/authoritative] | Versions: [number]

EVALUATION FORMAT (when Denis returns ChatGPT output):
📊 EVALUATION
Score: [X]/10
ICP Match: [X]/10 — [reason]
Messaging: [X]/10 — [reason]  
Differentiation: [X]/10 — [reason]
Objection Handling: [X]/10 — [reason]
Verdict: SHIP / REVISE
[If REVISE: write revision brief immediately]
```

### Step 4: Set Conversation Starters

Go to **Project → Settings → Conversation Starters**. Add these 4:

```
🧠 Plan my next campaign
```
```
📊 Evaluate this output
```
```
🗺️ Build my GTM strategy
```
```
🔄 Update my project context
```

### Step 5: Configure Style

Go to **Profile → Settings → Custom Instructions → How should Claude respond?**

```
Direct and precise. No preamble. No "Great question!" 
Lead with action or the answer.
For briefs: use the standard 📋 BRIEF format.
For evaluations: use the standard 📊 EVALUATION format.
Open an artifact for any document > 10 lines.
```

### Step 6: Extended Thinking

Extended thinking is available but **expensive**. Claude will use it only when Denis explicitly requests it:

- Allowed uses: Full ICP research from scratch, complete GTM strategy
- Trigger phrase: "Use deep thinking for this"
- Limit: Max 2–3 times/month
- Default: OFF (standard mode for all briefs and evaluations)

---

## PART 2 — CHATGPT SETUP

### Overview: 6 Execution GPTs

| # | GPT Name | Role | Web Browsing |
|---|----------|------|--------------|
| 1 | ICP Builder | Customer research · profiles · pain points | ✅ ON |
| 2 | Messaging Builder | Positioning · copy scoring · rewrites | ❌ OFF |
| 3 | Funnel Builder | Funnel design · friction mapping | ❌ OFF |
| 4 | Content Builder | Emails · ads · blog · social · sequences | ❌ OFF |
| 5 | Build Planner | Feature specs · launch plans | ❌ OFF |
| 6 | Landing Builder | Full landing page generation + scoring | ❌ OFF |

### Step 1: Access GPT Builder

Go to **chatgpt.com → Explore GPTs → Create a GPT** (requires ChatGPT Plus)

### Step 2: Build Each GPT

For each of the 6 GPTs below:

1. Click **Create a GPT → Configure**
2. Set **Name** and **Description** as shown
3. Set **Instructions**: paste the full contents of the corresponding `.md` file from the ChatGPT folder
4. Set **Conversation Starters**: copy the 4 starters from that file
5. Set **Capabilities**: enable/disable Web Browsing per the table above
6. Set **Canvas**: leave on (all GPTs auto-open canvas for 15+ line outputs)
7. Click **Save → Only me** (private GPTs)

---

### GPT 1: ICP Builder

**Name:** `ICP Builder`
**Description:** `Deep customer research — ICPs, pain points, buying triggers, real quotes from web`
**Instructions file:** `GPT_01_ICP_Builder.md`
**Web Browsing:** ON
**Conversation starters:**
```
Build my full ICP — I'll tell you the product and market
```
```
Find real customer pain points — pull from G2, Reddit, forums
```
```
Segment my audience — which ICP should I target first?
```
```
What does my ICP actually say about this problem?
```

---

### GPT 2: Messaging Builder

**Name:** `Messaging Builder`
**Description:** `Sharp positioning from scratch — or score and rebuild existing copy`
**Instructions file:** `GPT_02_Messaging_Builder.md`
**Web Browsing:** OFF
**Conversation starters:**
```
Build my positioning — here's what my product does and who it's for
```
```
Score this copy — what's weak and how do I fix it?
```
```
Write 3 versions of this headline — sharper, bolder, more specific
```
```
Punch up this cold email — give me 3 rewritten versions
```

---

### GPT 3: Funnel Builder

**Name:** `Funnel Builder`
**Description:** `Design full funnels, find conversion leaks, map friction at every stage`
**Instructions file:** `GPT_03_Funnel_Builder.md`
**Web Browsing:** OFF
**Conversation starters:**
```
Design my full funnel — from first touchpoint to first dollar
```
```
Find my biggest conversion leak — where am I losing people?
```
```
Build a nurture sequence plan — I'll tell you the product and ICP
```
```
Optimize my lead capture form — here's what I have now
```

---

### GPT 4: Content Builder

**Name:** `Content Builder`
**Description:** `Primary execution engine — emails, ads, blog posts, LinkedIn, sequences, newsletters`
**Instructions file:** `GPT_04_Content_Builder.md`
**Web Browsing:** OFF
**Conversation starters:**
```
Tighten this copy — make it 30% shorter without losing impact
```
```
Rewrite this for my ICP — I'll tell you who they are
```
```
Write me a content piece — blog post, email, LinkedIn thread, or ad
```
```
Give me 3 headline versions — bolder, clearer, more specific
```

---

### GPT 5: Build Planner

**Name:** `Build Planner`
**Description:** `Turn ideas into build plans — feature specs, launch plans, product-marketing alignment`
**Instructions file:** `GPT_05_Build_Planner.md`
**Web Browsing:** OFF
**Conversation starters:**
```
Turn this idea into a build plan — I'll describe what we want to ship
```
```
Write a feature spec for engineering — here's the user problem
```
```
Plan our launch — product + marketing + engineering, aligned
```
```
What should we build first? Help me prioritize the roadmap
```

---

### GPT 6: Landing Builder

**Name:** `Landing Builder`
**Description:** `Full landing page generation — every section written, scored, and ready to paste`
**Instructions file:** `GPT_06_Landing_Builder.md`
**Web Browsing:** OFF
**Conversation starters:**
```
Build me a landing page — I'll tell you the product and ICP
```
```
Write every section of my page — hero to footer, ready to paste
```
```
Critique my existing landing page — score it and rewrite the weak sections
```
```
Give me 3 hero headline options — then build out the strongest one
```

---

### Step 3: Set Up ChatGPT Projects (Optional but Recommended)

Projects in ChatGPT persist context across conversations. Create one per product/campaign.

1. **chatgpt.com → Projects → New Project**
2. Name: `[Product Name] Marketing`
3. Upload relevant context files from your Documentation Builder output
4. Use the GPTs above within this project for persistent context

---

## PART 3 — THE DAILY WORKFLOW

### Standard Operation (5 steps)

```
1. Open Claude.ai → Marketing OS project
   Tell Claude what you need ("Plan a cold email campaign for [ICP]")

2. Claude generates a structured brief:
   📋 BRIEF FOR CONTENT BUILDER
   Project: [name] | ICP: [description] | Goal: cold email sequence
   Format: 5-email sequence | Tone: direct | Versions: 3

3. Copy the brief → Open ChatGPT → Open Content Builder GPT
   Paste the brief. ChatGPT executes immediately (no re-clarifying).

4. ChatGPT returns scored output in canvas (paste-ready)
   Copy the output.

5. Return to Claude → Paste output
   "Evaluate this"
   Claude scores 1–10. If <7: revision brief generated immediately.
   If ≥7: ship it.
```

### What Goes to Claude (Brain Tasks)
- "What campaign should I run next?"
- "Evaluate this email sequence"
- "Build my ICP brief for the ICP Builder"
- "Score this positioning"
- "Plan the GTM for [feature]"

### What Goes to ChatGPT (Execution Tasks)
- Writing emails, ads, blog posts, LinkedIn threads
- Building landing page copy
- Deep ICP research from web (G2, Reddit, forums)
- Funnel mapping and friction analysis
- Feature specs and launch plans

---

## PART 4 — QUICK REFERENCE

### Brief Formats by GPT

**ICP Builder:**
```
📋 BRIEF FOR ICP BUILDER
Project: [name] | Market: [description] | Goal: [profile / pain points / segmentation]
Depth: [1 persona / full segmentation] | Web sources: [G2, Reddit, LinkedIn, forums]
```

**Messaging Builder:**
```
📋 BRIEF FOR MESSAGING BUILDER
Project: [name] | ICP: [description] | Goal: [build or score positioning]
Messaging pillars: [list] | Proof points: [list] | Competitors: [list]
```

**Funnel Builder:**
```
📋 BRIEF FOR FUNNEL BUILDER
Project: [name] | ICP: [description] | Goal: [design or audit]
Current funnel: [stages + known drop-offs] | Primary conversion: [action]
```

**Content Builder:**
```
📋 BRIEF FOR CONTENT BUILDER
Project: [name] | ICP: [description] | Goal: [what to produce]
Format: [email / sequence / ad / blog / thread / newsletter + length]
Messaging: [key messages] | Objections: [list] | Proof: [available]
Tone: [direct/warm/authoritative] | Versions: [number]
```

**Build Planner:**
```
📋 BRIEF FOR BUILD PLANNER
Project: [name] | Feature: [what we're building]
User: [who benefits + their context] | Goal: [success metric]
Scope: [MVP / full feature] | Ship target: [date or sprint]
```

**Landing Builder:**
```
📋 BRIEF FOR LANDING BUILDER
Project: [name] | ICP: [description] | Primary CTA: [action]
Sections: [which sections / full page] | Proof: [quote/stat/case study]
Messaging: [key messages] | Tone: [direct/warm/authoritative]
```

### Evaluation Rubric

| Score | Action |
|-------|--------|
| 9–10 | Ship immediately |
| 7–8 | Ship with minor edits |
| 5–6 | Revise — Claude writes revision brief |
| 1–4 | Rewrite — Claude writes new brief from scratch |

---

## PART 5 — TROUBLESHOOTING

**ChatGPT re-asks questions instead of executing the brief**
→ Add to the top of your paste: "Execute this brief immediately without asking clarifying questions."

**Claude writes content instead of generating a brief**
→ Say: "Don't write this yourself. Generate the brief for [GPT name]."

**Extended thinking turns on unexpectedly (high token use)**
→ Don't use phrases like "think deeply" or "analyze thoroughly" — these trigger thinking mode. Use "Use deep thinking" only when you explicitly want it.

**ICP Builder not finding web data**
→ Confirm Web Browsing is ON in GPT settings. Check with: "Search G2 reviews for [product category] — what do users complain about?"

**Canvas not opening in ChatGPT**
→ All GPTs auto-open canvas for outputs >15 lines. If it doesn't: type "Open canvas and rewrite this" in the same conversation.

---

*Marketing Hub Setup Guide v1.2 · Brain/Execution Architecture · 2026-04-07*


---


# Marketing OS — Research & GTM Framework
**Version:** 1.0
**Date:** 2026-04-07
**Purpose:** Foundation for all marketing projects. Guides research, ICP definition, GTM strategy, and positioning before any execution.

---

## Overview

Before any copywriting, emails, ads, or campaigns execute, the marketing hub runs through this research & GTM framework. This outputs a single **project-marketing-context.md** file that ALL 25+ skills reference.

**Workflow:**
1. Customer Research (who, what they want, where they are)
2. Competitive Analysis (landscape, positioning opportunities)
3. ICP Definition (ideal customer profile, segmentation)
4. Audience & Channel Mapping (where to reach them)
5. Messaging & Positioning (how to talk to them)
6. Brand & Story (why they should care)
7. GTM Strategy (which channels, which tactics, which metrics)

---

## Phase 1: Customer Research

**Purpose:** Understand the market, customer pain points, motivations, and behaviors.

**Methods:**
- **Interviews** (1:1 conversations with potential customers)
  - Open-ended: "What's your biggest challenge with [problem]?"
  - Solution-focused: "How do you currently solve this?"
  - Context: "Who influences your buying decision?"
  - Record: Customer quotes, pain points, buying signals

- **Surveys** (quantify patterns from interviews)
  - NPS questions (satisfaction baseline)
  - Job-to-be-done: "What outcome do you want?"
  - Channel preference: "Where do you spend time online?"
  - Decision criteria: "What matters most in a solution?"

- **Secondary Research** (existing data)
  - Market reports (industry size, growth rate)
  - Reddit/forums (where customers congregate, real language)
  - G2/Capterra reviews (competitor strengths/weaknesses, customer language)
  - Google Trends, search volume (demand validation)

- **Sales/Support Data** (if you have an existing product)
  - Most common objections
  - Churn reasons (exit surveys, failed cancellations)
  - Feature requests (what customers actually want)
  - Deal sizes, buying cycles, decision-makers

**Output:** Synthesis doc with:
- 3–5 key customer pain points (quoted, specific)
- Customer motivations (why they buy)
- Buying behavior (how they decide, who influences)
- Customer language (copy library for later)

---

## Phase 2: Competitive Analysis

**Purpose:** Understand the market landscape, identify positioning gaps.

**Questions to Answer:**
- Who are the direct competitors?
- What's their positioning? (how do they talk about their value?)
- What's their ICP? (who do they target?)
- What channels do they use? (content, ads, sales, community?)
- What are they good at? What are they weak at?
- Where's the positioning gap? (what are they *not* saying that matters to customers?)

**Methods:**
- **Competitor Site/Product Audit**
  - Homepage positioning (headline, tagline)
  - Pricing page (ICP signals, value prop)
  - Feature set (capabilities vs. alternatives)
  - Content strategy (what are they writing about?)

- **Sales Motion Review**
  - Do they use cold email? What's their angle?
  - Do they run paid ads? What's the creative strategy?
  - Community presence? (Discord, Slack, Reddit)

- **Review Sites** (G2, Capterra, Trustpilot)
  - Common praise (what customers love)
  - Common complaints (competitive vulnerabilities)
  - Compare to your strengths

**Output:** Competitive positioning matrix:
- Competitor | ICP | Messaging | Channels | Strength | Weakness | Positioning Gap

---

## Phase 3: ICP Definition

**Purpose:** Define who you're targeting. ICPs drive all downstream decisions (messaging, channels, budgets).

**ICP Framework:**

### Company Profile
- **Industry:** Which vertical? (SaaS, B2B, D2C, Enterprise?)
- **Company Size:** (employees, revenue, growth stage)
- **Geography:** (US, EU, Global?)
- **Business Model:** (subscription, one-time, service-based?)

### Role & Responsibility
- **Buyer Role:** (CEO, VP Marketing, Marketing Manager, IC?)
- **Budget Authority:** (does this person control spend?)
- **Success Metric:** (what does success look like for them?)
- **Team Structure:** (do they have a team, or solo?)

### Pain Points & Motivations
- **Primary Pain:** (what problem keeps them up at night?)
- **Secondary Pains:** (related problems that make the primary worse?)
- **Desired Outcome:** (what does "solved" look like?)
- **Buying Trigger:** (what event makes them start looking?)

### Buying Behavior
- **Buying Cycle:** (how long from awareness to decision?)
- **Decision-Makers:** (who influences the decision?)
- **Deal Size:** (budget range for solutions like yours?)
- **Objections:** (what stops them from buying?)

### Channel Affinity
- **Where They Spend Time:** (Twitter, Reddit, LinkedIn, Slack communities, industry events?)
- **Content Preference:** (blogs, videos, newsletters, podcasts?)
- **Sales Preference:** (self-serve, demos, sales calls?)

**Output:** 2–3 detailed ICP personas (use real data from research, not guesses).

---

## Phase 4: Audience & Channel Mapping

**Purpose:** Identify where to reach your ICP. This drives budget allocation.

**Channel Evaluation Matrix:**

For each potential channel, score 1–5 on:
- **Audience Match:** Does your ICP spend time here?
- **Volume:** How many of your ICP are on this channel?
- **Cost:** How expensive is it to reach them?
- **Conversion:** How likely are they to convert here?
- **Competitive Density:** How crowded is this channel?

**Common Channels:**

| Channel | Best For | Typical ICP | Cost | Notes |
|---------|----------|------------|------|-------|
| Cold Email | B2B outbound, lead gen | VP/Manager level | Low | High effort, high ROI if done right |
| LinkedIn | B2B, thought leadership, recruiting | Mid-market, enterprise | Medium | Algorithm-dependent, organic works |
| Twitter/X | Community, thought leadership, B2B | Founders, operators, tech | Low organic, high paid | Fast feedback loop |
| Reddit | Community, research, organic reach | Developers, enthusiasts | Low | Authentic conversations, no selling |
| Google Ads | High-intent searchers | Anyone with budget | High | Works best for transactional products |
| Content (Blog/SEO) | Long-term lead gen, thought leadership | Everyone | Low upfront, high long-term | Requires consistency |
| Paid Social (Facebook/Instagram) | Brand awareness, DTC, visual products | Consumers, D2C | Medium | Great for testing creative |
| Webinars/Events | Enterprise, high-touch sales | C-level, groups | Medium | Build authority, generate leads |
| Communities (Slack, Discord) | Engaged, loyal audience | Niche, power users | Low | Word-of-mouth amplification |

**Output:** Prioritized channel list with estimated audience size + cost per reach.

---

## Phase 5: Messaging & Positioning

**Purpose:** Define HOW you talk about your product. This is the foundation for all copywriting.

**Positioning Framework (One Sentence):**
*"For [ICP], [product] is the [category] that [unique value] because [reason]."*

Example: *"For early-stage founders, Mercury is the business banking platform that handles compliance automatically because founders hate dealing with banks."*

**Key Message Pillars (3–5 max):**

1. **Problem Validation** (what problem does your ICP have?)
   - Use customer language from research
   - Be specific (not "slow" but "spends 5 hours/week on manual invoicing")

2. **Unique Solution** (how does YOUR product solve it differently?)
   - What's different from competitors?
   - Why does that difference matter?

3. **Proof/Credibility** (why should they trust you?)
   - Case studies, customer testimonials, data
   - Years in market, team credentials, partnerships

4. **Desired Outcome** (what's the payoff?)
   - Time saved, revenue generated, stress reduced
   - Use their language, not marketing speak

5. **Call to Action** (what's the next step?)
   - "Try free," "Schedule demo," "Join community"
   - Specific, friction-minimal

**Messaging Tests:**
- Does it resonate with ICP language? (use customer quotes)
- Is it differentiated from competitors?
- Is it credible? (backed by data/proof)
- Does it clarify, not confuse?

**Output:** Positioning statement + 5 key message pillars with proof points.

---

## Phase 6: Brand & Storytelling

**Purpose:** Build emotional connection and trust. Why should they care beyond product features?

**Brand Questions:**
- **Origin Story:** Why did you start this? (What problem motivated you?)
- **Values:** What do you stand for? (Not fluffy, specific: "We believe founders shouldn't waste time on admin")
- **Vision:** Where are you going? (What's the bigger movement you're part of?)
- **Personality:** How do you sound? (Casual, formal, technical, playful?)

**Narrative Arc:**
1. **Before** (customer's current situation, pain)
2. **Moment** (the realization or event that changed things)
3. **After** (new possibility opened up)
4. **Call** (invitation to join the movement)

Example: *"Most founders spend 30% of their time on operations instead of building. We started [Company] because we couldn't stand watching great products die because of admin overhead. Today, 500+ teams have reclaimed that time. You could be next."*

**Output:** Brand story (1–2 paragraphs) + brand voice guide (how to sound authentic across channels).

---

## Phase 7: GTM Strategy

**Purpose:** Tie everything together. Which channels, which messages, which tactics, which metrics?

**GTM Plan Template:**

### Phase 1: Awareness (Weeks 1–4)
- **Channels:** [Tier 1 channels from Phase 4]
- **Tactics:**
  - Content: [topics from message pillars]
  - Paid: [audience + creative strategy]
  - Organic: [which communities, how often]
- **Budget:** [% allocation]
- **Metrics:** [awareness metrics: impressions, reach, website traffic]

### Phase 2: Consideration (Weeks 5–8)
- **Channels:** [deeper engagement channels]
- **Tactics:**
  - Email sequences: [nurture path]
  - Demos: [sales process]
  - Content: [comparison, case studies]
- **Budget:** [% allocation]
- **Metrics:** [engagement: opens, clicks, demo requests]

### Phase 3: Decision (Weeks 9+)
- **Channels:** [high-touch, conversion channels]
- **Tactics:**
  - Sales calls: [pitch, objection handling]
  - Trials/Free plans: [conversion optimization]
  - Pricing/Offer: [packaging strategy]
- **Budget:** [% allocation]
- **Metrics:** [conversions: sign-ups, trials, sales]

### Post-Launch (Ongoing)
- **Retention:** [engagement, churn prevention]
- **Expansion:** [upsell, advocacy]
- **Feedback Loop:** [customer success, research]

**Output:** Visual GTM roadmap + 90-day launch plan.

---

## Phase 8: Output — project-marketing-context.md

Once you've completed all 7 phases, synthesize into ONE file: **project-marketing-context.md**

This file is the nerve center. ALL 25+ marketing skills reference it.

**Structure:**
```
# [Project Name] — Marketing Context

## ICP
- Company: [profile]
- Role: [buyer role]
- Pain Points: [3 key pains]
- Success Metric: [what success looks like]

## Positioning
- Statement: [one-sentence positioning]
- Key Messages: [5 pillars with proof]
- Tagline: [short brand promise]

## Brand & Story
- Origin: [why we started]
- Values: [what we stand for]
- Voice: [how we sound]

## Channels
- Tier 1: [primary, highest ROI]
- Tier 2: [secondary, support]
- Budget Allocation: [%]

## GTM Plan
- Awareness Tactics: [content, ads, organic]
- Consideration Tactics: [nurture, demos, case studies]
- Decision Tactics: [sales, pricing, trials]
- Metrics: [KPIs by phase]

## Competitive Positioning
- Alternatives: [main competitors]
- Gaps: [where we win]

## Customer Language
- Pain Point Quotes: [from interviews]
- Objections: [common blockers]
- Desires: [what they want to hear]
```

---

## Quality Gates (Research & GTM Phase)

Before moving to execution (copywriting, emails, ads), confirm:

- [ ] ICP defined with real customer data (not guesses)
- [ ] Positioning tested against competitive landscape
- [ ] Messaging tied to customer language (not marketing jargon)
- [ ] Channels prioritized by audience + cost
- [ ] GTM plan has specific tactics + metrics
- [ ] project-marketing-context.md created and current

---

## Token Optimization

This phase is **research-intensive**, so expect higher token usage upfront. But it pays for itself:
- Reusable context (cache it, reference it across all skills)
- Fewer iterations (clear positioning = faster execution)
- Higher ROI campaigns (right message to right audience)

**Estimated tokens:** 4–6K per project (one-time cost, amortized across all future executions).

---

*Marketing OS v1.0 · Research & GTM Framework · 2026-04-07*


---


# Marketing Hub — Quick Start
**v1.3 · 2026-04-07 · Brain/Execution Architecture**

---

## The System in 30 Seconds

**Claude.ai = Brain.** Strategy, context, brief generation, quality evaluation.
**ChatGPT = Engine.** All content writing, research, and execution.

```
You → Claude → Brief → ChatGPT → Output → Claude → Ship or Revise
```

---

## Platform Setup (Do This Once)

### Claude.ai
1. Create Project: `Marketing OS`
2. Upload to Knowledge: `CONTEXT_Product.md`, `CONTEXT_Technical.md`, `MARKETING_OS_CLAUDE_v1.3_2026-04-07.md`
3. Custom Instructions: paste from SetupGuide Part 1, Step 3
4. Conversation starters: `🧠 Plan my next campaign` · `📊 Evaluate this output` · `🗺️ Build my GTM strategy` · `🔄 Update my project context`

### ChatGPT (6 GPTs — all private)

| GPT | Instructions File | Web Browsing |
|-----|-------------------|--------------|
| ICP Builder | `GPT_01_ICP_Builder.md` | ✅ ON |
| Messaging Builder | `GPT_02_Messaging_Builder.md` | ❌ OFF |
| Funnel Builder | `GPT_03_Funnel_Builder.md` | ❌ OFF |
| Content Builder | `GPT_04_Content_Builder.md` | ❌ OFF |
| Build Planner | `GPT_05_Build_Planner.md` | ❌ OFF |
| Landing Builder | `GPT_06_Landing_Builder.md` | ❌ OFF |

Full setup instructions: `MARKETING_OS_SetupGuide_v1.2_2026-04-07.md`

---

## Daily Loop

```
1. Tell Claude what you need
   → "Plan a cold email campaign for SaaS founders"

2. Claude routes and generates a brief
   → 📋 BRIEF FOR CONTENT BUILDER
     Project: ... | ICP: SaaS founders | Goal: 5-email sequence
     Format: email sequence | Tone: direct | Versions: 3

3. Paste brief into the right ChatGPT GPT
   → Content Builder executes immediately

4. Paste output back into Claude
   → "Evaluate this"

5. Claude scores it
   → ≥7: ship | <7: Claude writes revision brief → back to ChatGPT
```

---

## What to Ask Claude

| You need | Say to Claude |
|----------|---------------|
| New campaign idea | "Plan my next campaign for [ICP]" |
| Evaluate content | "Evaluate this" + paste ChatGPT output |
| ICP research | "Build an ICP research brief" |
| Positioning review | "Score this copy" + paste copy |
| GTM plan | "Build my GTM strategy for [launch]" |
| Update context | "Update my project context — [changes]" |

## What to Send to ChatGPT

| Content type | GPT to use |
|--------------|------------|
| ICP profiles, pain points, web research | ICP Builder |
| Positioning, copy scoring, rewrites | Messaging Builder |
| Funnel design, conversion audit | Funnel Builder |
| Emails, ads, blog, LinkedIn, social | Content Builder |
| Feature specs, launch plans | Build Planner |
| Full landing pages | Landing Builder |

---

## Claude Quality Evaluation

Every output Claude evaluates gets scored on 4 dimensions:

```
📊 EVALUATION
Score: [X]/10
ICP Match: [X]/10
Messaging: [X]/10
Differentiation: [X]/10
Objection Handling: [X]/10
Verdict: SHIP / REVISE
```

**≥7 → ship. <7 → Claude writes revision brief → back to ChatGPT.**

---

## Token Budget

| Task | Claude tokens |
|------|---------------|
| Brief generation | ~300–500 |
| Evaluation | ~200–400 |
| Strategy session | ~1,000–2,000 |
| Extended thinking (rare) | ~5,000–8,000 |
| **Monthly total** | **~8–15K** |

Extended thinking: use only when explicitly requested ("Use deep thinking"). Max 2–3x/month.

---

## Files in This Bundle

```
Claude Files:
  MARKETING_OS_CLAUDE_v1.3_2026-04-07.md    ← Claude's brain instructions
  CONTEXT_Product.md                          ← Product context (fill in)
  CONTEXT_Technical.md                        ← Stack + integrations (fill in)
  IMPLEMENTATION.md                           ← GTM strategy

ChatGPT GPT Files:
  GPT_01_ICP_Builder.md
  GPT_02_Messaging_Builder.md
  GPT_03_Funnel_Builder.md
  GPT_04_Content_Builder.md                   ← Primary execution engine
  GPT_05_Build_Planner.md
  GPT_06_Landing_Builder.md

ChatGPT Project Files:
  PROJECT_01 through PROJECT_05               ← Per-product context files

Setup & Reference:
  MARKETING_OS_SetupGuide_v1.2_2026-04-07.md ← Full setup instructions
  QUICK_START.md                              ← This file

Consolidated (for Claude.ai upload):
  CONTEXT_MarketingOS.md                      ← Claude instructions + context
  CONTEXT_ChatGPT_GPTs.md                     ← All 6 GPT instructions
  IMPLEMENTATION_GTM.md                       ← GTM + product + technical
```

---

*Marketing Hub Quick Start v1.3 · 2026-04-07*
