# Marketing OS — Research & GTM Framework
**Version:** 1.0
**Date:** 2026-04-07
**Purpose:** Foundation for all marketing projects. Guides research, ICP definition, GTM strategy, and positioning before any execution.

---

## Overview

Before any copywriting, emails, ads, or campaigns execute, the marketing hub runs through this research & GTM framework. This outputs a single **project-marketing-context.md** file that ALL 25+ skills reference.

**Workflow:**
1. Customer Research (who, what they want, where they are)
2. Competitive Analysis (landscape, positioning opportunities)
3. ICP Definition (ideal customer profile, segmentation)
4. Audience & Channel Mapping (where to reach them)
5. Messaging & Positioning (how to talk to them)
6. Brand & Story (why they should care)
7. GTM Strategy (which channels, which tactics, which metrics)

---

## Phase 1: Customer Research

**Purpose:** Understand the market, customer pain points, motivations, and behaviors.

**Methods:**
- **Interviews** (1:1 conversations with potential customers)
  - Open-ended: "What's your biggest challenge with [problem]?"
  - Solution-focused: "How do you currently solve this?"
  - Context: "Who influences your buying decision?"
  - Record: Customer quotes, pain points, buying signals

- **Surveys** (quantify patterns from interviews)
  - NPS questions (satisfaction baseline)
  - Job-to-be-done: "What outcome do you want?"
  - Channel preference: "Where do you spend time online?"
  - Decision criteria: "What matters most in a solution?"

- **Secondary Research** (existing data)
  - Market reports (industry size, growth rate)
  - Reddit/forums (where customers congregate, real language)
  - G2/Capterra reviews (competitor strengths/weaknesses, customer language)
  - Google Trends, search volume (demand validation)

- **Sales/Support Data** (if you have an existing product)
  - Most common objections
  - Churn reasons (exit surveys, failed cancellations)
  - Feature requests (what customers actually want)
  - Deal sizes, buying cycles, decision-makers

**Output:** Synthesis doc with:
- 3–5 key customer pain points (quoted, specific)
- Customer motivations (why they buy)
- Buying behavior (how they decide, who influences)
- Customer language (copy library for later)

---

## Phase 2: Competitive Analysis

**Purpose:** Understand the market landscape, identify positioning gaps.

**Questions to Answer:**
- Who are the direct competitors?
- What's their positioning? (how do they talk about their value?)
- What's their ICP? (who do they target?)
- What channels do they use? (content, ads, sales, community?)
- What are they good at? What are they weak at?
- Where's the positioning gap? (what are they *not* saying that matters to customers?)

**Methods:**
- **Competitor Site/Product Audit**
  - Homepage positioning (headline, tagline)
  - Pricing page (ICP signals, value prop)
  - Feature set (capabilities vs. alternatives)
  - Content strategy (what are they writing about?)

- **Sales Motion Review**
  - Do they use cold email? What's their angle?
  - Do they run paid ads? What's the creative strategy?
  - Community presence? (Discord, Slack, Reddit)

- **Review Sites** (G2, Capterra, Trustpilot)
  - Common praise (what customers love)
  - Common complaints (competitive vulnerabilities)
  - Compare to your strengths

**Output:** Competitive positioning matrix:
- Competitor | ICP | Messaging | Channels | Strength | Weakness | Positioning Gap

---

## Phase 3: ICP Definition

**Purpose:** Define who you're targeting. ICPs drive all downstream decisions (messaging, channels, budgets).

**ICP Framework:**

### Company Profile
- **Industry:** Which vertical? (SaaS, B2B, D2C, Enterprise?)
- **Company Size:** (employees, revenue, growth stage)
- **Geography:** (US, EU, Global?)
- **Business Model:** (subscription, one-time, service-based?)

### Role & Responsibility
- **Buyer Role:** (CEO, VP Marketing, Marketing Manager, IC?)
- **Budget Authority:** (does this person control spend?)
- **Success Metric:** (what does success look like for them?)
- **Team Structure:** (do they have a team, or solo?)

### Pain Points & Motivations
- **Primary Pain:** (what problem keeps them up at night?)
- **Secondary Pains:** (related problems that make the primary worse?)
- **Desired Outcome:** (what does "solved" look like?)
- **Buying Trigger:** (what event makes them start looking?)

### Buying Behavior
- **Buying Cycle:** (how long from awareness to decision?)
- **Decision-Makers:** (who influences the decision?)
- **Deal Size:** (budget range for solutions like yours?)
- **Objections:** (what stops them from buying?)

### Channel Affinity
- **Where They Spend Time:** (Twitter, Reddit, LinkedIn, Slack communities, industry events?)
- **Content Preference:** (blogs, videos, newsletters, podcasts?)
- **Sales Preference:** (self-serve, demos, sales calls?)

**Output:** 2–3 detailed ICP personas (use real data from research, not guesses).

---

## Phase 4: Audience & Channel Mapping

**Purpose:** Identify where to reach your ICP. This drives budget allocation.

**Channel Evaluation Matrix:**

For each potential channel, score 1–5 on:
- **Audience Match:** Does your ICP spend time here?
- **Volume:** How many of your ICP are on this channel?
- **Cost:** How expensive is it to reach them?
- **Conversion:** How likely are they to convert here?
- **Competitive Density:** How crowded is this channel?

**Common Channels:**

| Channel | Best For | Typical ICP | Cost | Notes |
|---------|----------|------------|------|-------|
| Cold Email | B2B outbound, lead gen | VP/Manager level | Low | High effort, high ROI if done right |
| LinkedIn | B2B, thought leadership, recruiting | Mid-market, enterprise | Medium | Algorithm-dependent, organic works |
| Twitter/X | Community, thought leadership, B2B | Founders, operators, tech | Low organic, high paid | Fast feedback loop |
| Reddit | Community, research, organic reach | Developers, enthusiasts | Low | Authentic conversations, no selling |
| Google Ads | High-intent searchers | Anyone with budget | High | Works best for transactional products |
| Content (Blog/SEO) | Long-term lead gen, thought leadership | Everyone | Low upfront, high long-term | Requires consistency |
| Paid Social (Facebook/Instagram) | Brand awareness, DTC, visual products | Consumers, D2C | Medium | Great for testing creative |
| Webinars/Events | Enterprise, high-touch sales | C-level, groups | Medium | Build authority, generate leads |
| Communities (Slack, Discord) | Engaged, loyal audience | Niche, power users | Low | Word-of-mouth amplification |

**Output:** Prioritized channel list with estimated audience size + cost per reach.

---

## Phase 5: Messaging & Positioning

**Purpose:** Define HOW you talk about your product. This is the foundation for all copywriting.

**Positioning Framework (One Sentence):**
*"For [ICP], [product] is the [category] that [unique value] because [reason]."*

Example: *"For early-stage founders, Mercury is the business banking platform that handles compliance automatically because founders hate dealing with banks."*

**Key Message Pillars (3–5 max):**

1. **Problem Validation** (what problem does your ICP have?)
   - Use customer language from research
   - Be specific (not "slow" but "spends 5 hours/week on manual invoicing")

2. **Unique Solution** (how does YOUR product solve it differently?)
   - What's different from competitors?
   - Why does that difference matter?

3. **Proof/Credibility** (why should they trust you?)
   - Case studies, customer testimonials, data
   - Years in market, team credentials, partnerships

4. **Desired Outcome** (what's the payoff?)
   - Time saved, revenue generated, stress reduced
   - Use their language, not marketing speak

5. **Call to Action** (what's the next step?)
   - "Try free," "Schedule demo," "Join community"
   - Specific, friction-minimal

**Messaging Tests:**
- Does it resonate with ICP language? (use customer quotes)
- Is it differentiated from competitors?
- Is it credible? (backed by data/proof)
- Does it clarify, not confuse?

**Output:** Positioning statement + 5 key message pillars with proof points.

---

## Phase 6: Brand & Storytelling

**Purpose:** Build emotional connection and trust. Why should they care beyond product features?

**Brand Questions:**
- **Origin Story:** Why did you start this? (What problem motivated you?)
- **Values:** What do you stand for? (Not fluffy, specific: "We believe founders shouldn't waste time on admin")
- **Vision:** Where are you going? (What's the bigger movement you're part of?)
- **Personality:** How do you sound? (Casual, formal, technical, playful?)

**Narrative Arc:**
1. **Before** (customer's current situation, pain)
2. **Moment** (the realization or event that changed things)
3. **After** (new possibility opened up)
4. **Call** (invitation to join the movement)

Example: *"Most founders spend 30% of their time on operations instead of building. We started [Company] because we couldn't stand watching great products die because of admin overhead. Today, 500+ teams have reclaimed that time. You could be next."*

**Output:** Brand story (1–2 paragraphs) + brand voice guide (how to sound authentic across channels).

---

## Phase 7: GTM Strategy

**Purpose:** Tie everything together. Which channels, which messages, which tactics, which metrics?

**GTM Plan Template:**

### Phase 1: Awareness (Weeks 1–4)
- **Channels:** [Tier 1 channels from Phase 4]
- **Tactics:**
  - Content: [topics from message pillars]
  - Paid: [audience + creative strategy]
  - Organic: [which communities, how often]
- **Budget:** [% allocation]
- **Metrics:** [awareness metrics: impressions, reach, website traffic]

### Phase 2: Consideration (Weeks 5–8)
- **Channels:** [deeper engagement channels]
- **Tactics:**
  - Email sequences: [nurture path]
  - Demos: [sales process]
  - Content: [comparison, case studies]
- **Budget:** [% allocation]
- **Metrics:** [engagement: opens, clicks, demo requests]

### Phase 3: Decision (Weeks 9+)
- **Channels:** [high-touch, conversion channels]
- **Tactics:**
  - Sales calls: [pitch, objection handling]
  - Trials/Free plans: [conversion optimization]
  - Pricing/Offer: [packaging strategy]
- **Budget:** [% allocation]
- **Metrics:** [conversions: sign-ups, trials, sales]

### Post-Launch (Ongoing)
- **Retention:** [engagement, churn prevention]
- **Expansion:** [upsell, advocacy]
- **Feedback Loop:** [customer success, research]

**Output:** Visual GTM roadmap + 90-day launch plan.

---

## Phase 8: Output — project-marketing-context.md

Once you've completed all 7 phases, synthesize into ONE file: **project-marketing-context.md**

This file is the nerve center. ALL 25+ marketing skills reference it.

**Structure:**
```
# [Project Name] — Marketing Context

## ICP
- Company: [profile]
- Role: [buyer role]
- Pain Points: [3 key pains]
- Success Metric: [what success looks like]

## Positioning
- Statement: [one-sentence positioning]
- Key Messages: [5 pillars with proof]
- Tagline: [short brand promise]

## Brand & Story
- Origin: [why we started]
- Values: [what we stand for]
- Voice: [how we sound]

## Channels
- Tier 1: [primary, highest ROI]
- Tier 2: [secondary, support]
- Budget Allocation: [%]

## GTM Plan
- Awareness Tactics: [content, ads, organic]
- Consideration Tactics: [nurture, demos, case studies]
- Decision Tactics: [sales, pricing, trials]
- Metrics: [KPIs by phase]

## Competitive Positioning
- Alternatives: [main competitors]
- Gaps: [where we win]

## Customer Language
- Pain Point Quotes: [from interviews]
- Objections: [common blockers]
- Desires: [what they want to hear]
```

---

## Quality Gates (Research & GTM Phase)

Before moving to execution (copywriting, emails, ads), confirm:

- [ ] ICP defined with real customer data (not guesses)
- [ ] Positioning tested against competitive landscape
- [ ] Messaging tied to customer language (not marketing jargon)
- [ ] Channels prioritized by audience + cost
- [ ] GTM plan has specific tactics + metrics
- [ ] project-marketing-context.md created and current

---

## Token Optimization

This phase is **research-intensive**, so expect higher token usage upfront. But it pays for itself:
- Reusable context (cache it, reference it across all skills)
- Fewer iterations (clear positioning = faster execution)
- Higher ROI campaigns (right message to right audience)

**Estimated tokens:** 4–6K per project (one-time cost, amortized across all future executions).

---

*Marketing OS v1.0 · Research & GTM Framework · 2026-04-07*
# [PROJECT NAME] — Marketing Context
**Version:** 1.0
**Date:** YYYY-MM-DD
**Project:** [Project/Client Name]
**Created by:** Denis
**Status:** [Draft / Active / Archived]

---

## Quick Reference

**ICP:** [1 sentence description of ideal customer]
**Positioning:** [1 sentence positioning statement]
**Primary Channels:** [Tier 1 channels, max 3]
**GTM Phase:** [Research / Launch / Scaling / Optimizing]

---

## Section 1: ICP (Ideal Customer Profile)

### Company Profile
- **Industry:** [Which vertical? SaaS, B2B, D2C, Enterprise, etc.]
- **Company Size:** [# employees, revenue range, growth stage]
- **Geography:** [Target regions: US, EU, APAC, Global?]
- **Business Model:** [Subscription, one-time, service-based, marketplace?]
- **Revenue Model:** [How do THEY make money?]

### Buyer Role & Responsibility
- **Primary Buyer Title:** [CEO, VP Marketing, Marketing Manager, IC developer, etc.]
- **Secondary Influences:** [Who else influences the decision?]
- **Budget Authority:** [Does this person control spend? How much?]
- **Success Metric (Their's):** [What does winning look like for them?]
- **Reporting Structure:** [Do they have a team? How big?]

### Pain Points (Use Customer Quotes)
1. **Primary Pain:** [Top problem] — Quote: *"[customer language]"*
2. **Secondary Pain:** [Related problem] — Quote: *"[customer language]"*
3. **Tertiary Pain:** [Underlying problem] — Quote: *"[customer language]"*

### Motivations & Desired Outcome
- **Core Desire:** [What outcome do they want?]
- **Buying Trigger:** [What event makes them start looking?]
- **Timeline:** [How urgent is this problem?]
- **Constraints:** [Budget caps, technical requirements, political blockers?]

### Buying Behavior
- **Buying Cycle:** [How long from awareness to decision? Days, weeks, months?]
- **Decision Process:** [Self-serve, demo, committee, procurement?]
- **Deal Size:** [Average contract value for solutions like yours?]
- **Common Objections:** [What stops them from buying?]
  - Objection 1: [and how we address it]
  - Objection 2: [and how we address it]
  - Objection 3: [and how we address it]

### Channel Affinity
- **Primary Digital Channels:** [Twitter, LinkedIn, Reddit, Slack communities, industry forums?]
- **Content Format Preference:** [Blogs, videos, newsletters, podcasts, whitepapers, case studies?]
- **Sales Preference:** [Self-serve, freemium, demos, cold calls, partner referrals?]
- **Information Sources:** [Where do they research solutions? G2, Reddit, peer recommendations, analyst reports?]

---

## Section 2: Positioning & Messaging

### Positioning Statement (One Sentence)
*"For [ICP], [Product] is the [Category] that [Unique Value] because [Reason]."*

Example: *"For early-stage founders, Mercury is the business banking platform that handles compliance automatically because founders hate dealing with traditional banks."*

**Your positioning:**
[Insert here]

---

### Key Message Pillars (Max 5)

#### Pillar 1: Problem Validation
- **Message:** [State the problem in customer language, not features]
- **Proof:** [Data, customer quote, stat from research]
- **Why It Matters:** [Connection to their success metric]

#### Pillar 2: Unique Solution
- **Message:** [What's different about your approach?]
- **Proof:** [Competitive differentiation, customer testimonial]
- **Why It Matters:** [Specific outcome they get]

#### Pillar 3: Credibility & Trust
- **Message:** [Why should they believe you?]
- **Proof:** [Case study, customer count, years in market, team creds]
- **Why It Matters:** [Risk reduction]

#### Pillar 4: Desired Outcome
- **Message:** [What's the payoff? What changes for them?]
- **Proof:** [Customer success story, metric improvement]
- **Why It Matters:** [Their version of success]

#### Pillar 5: Social Proof / Movement
- **Message:** [Why are others choosing this? What's the trend?]
- **Proof:** [Case studies, testimonials, community size]
- **Why It Matters:** [FOMO, validation, credibility]

---

### Customer Language Library

**Use these phrases verbatim in copy, emails, ads:**

Pain Point Language (from customer interviews):
- [Quote 1: "[customer pain point in their words]"]
- [Quote 2: "[customer pain point in their words]"]
- [Quote 3: "[customer pain point in their words]"]

Desire Language (what they want):
- [Quote 1: "[desired outcome in their words]"]
- [Quote 2: "[desired outcome in their words]"]

Objection Language (common blockers):
- [Objection 1: "[how they phrase resistance]"]
- [Objection 2: "[how they phrase resistance]"]

---

## Section 3: Brand & Story

### Origin Story
*Why did you start this? What problem motivated you?*

[Your answer, 1–2 paragraphs. Use this in long-form content, landing pages, and about pages.]

---

### Brand Values
*What do you stand for? (Not fluffy, be specific)*

1. [Value 1]: [Why it matters, specific example]
2. [Value 2]: [Why it matters, specific example]
3. [Value 3]: [Why it matters, specific example]

---

### Brand Voice & Personality

- **Tone:** [Casual, formal, technical, playful, irreverent, authoritative?]
- **Vocabulary:** [Jargon level — technical deep-dive or plain English?]
- **Sentence Length:** [Short and punchy, or detailed and thorough?]
- **Humor:** [Funny, dry, none?]
- **Example Phrase:** [How would you describe your product in one sentence, in your voice?]

---

### Narrative Arc (Customer Journey)

**BEFORE:** *[Customer's current situation, pain, frustration]*
> Example: "Most founders spend 30% of their time on operations instead of building."

**MOMENT:** *[The realization or trigger that changes things]*
> Example: "We watched a great product die because operations overhead killed momentum."

**AFTER:** *[New possibility opened up]*
> Example: "What if founders could reclaim that 30% and focus on what matters?"

**MOVEMENT:** *[Invitation to join]*
> Example: "500+ teams have already reclaimed their time. Join the ops revolution."

---

## Section 4: Competitive Positioning

### Direct Competitors
- **Competitor 1:** [Name]
  - Positioning: [How do they position?]
  - ICP: [Who do they target?]
  - Strength: [What are they good at?]
  - Weakness: [Where are they vulnerable?]

- **Competitor 2:** [Name]
  - Positioning: [How do they position?]
  - ICP: [Who do they target?]
  - Strength: [What are they good at?]
  - Weakness: [Where are they vulnerable?]

### Positioning Gaps (Where You Win)
- **Gap 1:** [They don't talk about X, but our ICP cares about X]
- **Gap 2:** [They focus on feature Y, but our ICP cares about outcome Z]
- **Gap 3:** [They target big enterprise, but our ICP is SMB]

### Competitive Advantage
*What can you uniquely claim that competitors can't (or won't)?*
- [Unique claim 1 + proof]
- [Unique claim 2 + proof]

---

## Section 5: Go-To-Market (GTM) Strategy

### Awareness Phase (Weeks 1–4)
**Goal:** Get your ICP to know you exist.

**Primary Channels:**
1. [Channel]: [Tactic — e.g., "Cold email outreach to [title] at [company size]"]
2. [Channel]: [Tactic — e.g., "Content on [topic] targeting [keyword]"]
3. [Channel]: [Tactic — e.g., "Paid ads to [audience]"]

**Budget Allocation:** [%]
**Key Metrics:** [impressions, reach, website traffic, opens]
**Success Threshold:** [e.g., "500 impressions, 50 visits, 10 opens"]

---

### Consideration Phase (Weeks 5–8)
**Goal:** Help them evaluate if you're a fit.

**Primary Tactics:**
1. [Tactic]: [e.g., "Email sequence: problem → solution → proof → CTA"]
2. [Tactic]: [e.g., "Case study on [specific use case]"]
3. [Tactic]: [e.g., "Demo video or product walkthrough"]

**Budget Allocation:** [%]
**Key Metrics:** [engagement rate, click rate, demo requests]
**Success Threshold:** [e.g., "30% email engagement, 5 demo requests"]

---

### Decision Phase (Weeks 9+)
**Goal:** Convert consideration to decision.

**Primary Tactics:**
1. [Tactic]: [e.g., "Sales call with [offer]"]
2. [Tactic]: [e.g., "Free trial with [incentive]"]
3. [Tactic]: [e.g., "Pricing + packaging strategy"]

**Budget Allocation:** [%]
**Key Metrics:** [conversion rate, trial start rate, sales]
**Success Threshold:** [e.g., "5% conversion, 10 trials, 2 sales"]

---

### Post-Launch (Ongoing)
**Retention Tactics:** [How will you keep them happy?]
**Expansion Tactics:** [How will you grow their spend?]
**Feedback Loop:** [How will you learn and improve?]

---

## Section 6: Campaign Calendar

### Q1 Campaign
- **Campaign Name:** [e.g., "Cold Email Blitz"]
- **Timeline:** [Dates]
- **Channels:** [Primary channels for this campaign]
- **Target Audience:** [Specific segment]
- **Messaging Focus:** [Which pillar(s)?]
- **Success Metrics:** [KPIs]
- **Expected Spend:** [$]

### Q2 Campaign
[Repeat above]

---

## Section 7: Metrics & Reporting

### North Star Metric
[What's the one number that matters most? e.g., "Monthly Recurring Revenue" or "Active Users"]

### Supporting Metrics
| Metric | Current | Target (90 days) | Target (6 months) |
|--------|---------|-------------------|-------------------|
| [Awareness metric] | [baseline] | [goal] | [goal] |
| [Engagement metric] | [baseline] | [goal] | [goal] |
| [Conversion metric] | [baseline] | [goal] | [goal] |
| [Retention metric] | [baseline] | [goal] | [goal] |

### Reporting Cadence
- Weekly: [Which metrics? who sees them?]
- Monthly: [Review and iterate?]
- Quarterly: [Deep dive + strategy adjust?]

---

## Section 8: Assumptions & Risks

### Key Assumptions (Mark with [ASSUMED] or [INFERRED])
- [ASSUMED] ICP has budget of [amount] for solutions like ours
- [INFERRED] Cold email will generate 3–5% reply rate based on [data]
- [NEEDS INPUT] Competitor analysis — need to verify [X]

### Known Risks
- **Risk 1:** [Risk description] → Mitigation: [How will you handle it?]
- **Risk 2:** [Risk description] → Mitigation: [How will you handle it?]

---

## Section 9: Document History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | YYYY-MM-DD | Initial context created |
| 1.1 | YYYY-MM-DD | [Updated ICP based on research] |
| 2.0 | YYYY-MM-DD | [Major pivot in positioning] |

---

## How This Doc Is Used

**This file is loaded by:**
- CLAUDE.md (detects active project)
- All 25+ marketing skills (reference ICP, messaging, channels)
- All execution docs (copywriting, emails, ads pull from messaging pillars)
- Evaluation framework (measures success against defined metrics)

**Update this doc when:**
- You conduct new customer research
- Competitive landscape shifts
- Messaging isn't resonating
- Campaign results suggest ICP changes
- New channel opportunity emerges

**Never:**
- Use outdated context (always check version + date)
- Assume context from previous project applies (each project gets its own file)
- Proceed to execution without confirming this doc is complete and current

---

*Marketing OS v1.0 · Project Context Template · 2026-04-07*
*Template for use by Denis across all marketing projects*
# Marketing OS — Backlog & Improvements
**Version:** 1.0 | **Date:** 2026-04-07 | **Status:** Active System

---

## System Status
✅ **Production Ready** — All core docs generated, quality gated (85/100+), ready to use.

---

## Known Gaps & Improvements

### Tier 1: Critical (Do First)
- [ ] **Test with first real project** — Run a complete workflow (research → execution → measurement) on a real client/project to validate system works end-to-end
- [ ] **Create 3 sample project contexts** — Example contexts for B2B SaaS, eCommerce, Agency Services (template library)
- [ ] **Document token overage handling** — What to do if a campaign exceeds budget mid-execution

### Tier 2: Important (Next 2 Weeks)
- [ ] **Add ChatGPT compatibility layer** — Simplified system prompt for ChatGPT compatibility (currently optimized for Claude)
- [ ] **Build monthly metric dashboard template** — Simple spreadsheet to track: tokens spent, campaigns run, ROI per channel
- [ ] **Create evaluation rubric checklist** — Printable/shareable version of the 4-question eval framework
- [ ] **Add case study template** — How to document and share winning angles/campaigns
- [ ] **Document skill failure modes** — If a skill doesn't work (API issue, context unclear), what's the fallback?

### Tier 3: Nice-to-Have (Next Month)
- [ ] **Video walkthrough** — 5-minute video: How to set up and run first campaign
- [ ] **Integration guides** — How to connect to HubSpot, Mailchimp, Pipedrive, LinkedIn Ads
- [ ] **AI evaluation evals** — Automated scoring of outputs using llm-evaluation skill
- [ ] **Competitive positioning library** — Industry-specific positioning examples (SaaS, e-commerce, agencies, etc.)
- [ ] **Mobile-friendly checklist** — Simplified checklist for on-the-go campaign management
- [ ] **Budget forecasting tool** — Spreadsheet to forecast monthly token spend by project/channel

---

## Feature Requests (Post-Launch)

### Research & Strategy Enhancements
- [ ] **Auto-generate ICP personas** — Instead of manual interviews, use AI to synthesize persona from company description
- [ ] **Competitive war game template** — Structured framework for war-gaming against key competitors
- [ ] **Market sizing calculator** — Tool to estimate TAM/SAM/SOM for budget allocation

### Execution Enhancements
- [ ] **Email A/B testing template** — Pre-built test designs for common scenarios (subject line, opening hook, CTA text)
- [ ] **Landing page multivariate test** — Beyond A/B, test 3+ variants simultaneously
- [ ] **Social media content calendar template** — Integrated with outbound strategy
- [ ] **LinkedIn content strategy** — Specific skill or module for organic LinkedIn growth
- [ ] **Webinar/event marketing module** — Campaign flow for live events
- [ ] **Partnership co-marketing template** — How to leverage partner channels

### Measurement Enhancements
- [ ] **Real-time dashboard integration** — Pull live campaign metrics (opens, clicks, conversions) into system
- [ ] **Automated anomaly detection** — Flag campaigns that underperform vs. baseline
- [ ] **Attribution modeling** — Track which touchpoint actually drove the conversion
- [ ] **Cohort analysis template** — Analyze performance by customer segment

### Optimization Enhancements
- [ ] **Automated A/B test runner** — Run tests without manual intervention
- [ ] **Predictive model for winning angles** — ML model trained on past results to predict next winning message
- [ ] **Churn prediction** — Identify customers likely to churn before it happens
- [ ] **LTV calculator** — Customer lifetime value by segment/channel

---

## Known Issues & Workarounds

### Issue 1: Project Context Gets Stale
**Description:** If ICP/messaging changes in reality but isn't updated in project context, campaigns can miss.
**Workaround:** Review project context every 2 weeks. Update if metrics suggest changes.
**Fix:** [Tier 2] Automated context freshness check (flag contexts older than 3 weeks)

### Issue 2: Token Budget Overage (Mid-Campaign)
**Description:** If campaign scope expands mid-execution, token budget can be exceeded.
**Workaround:** Check token cost before executing. Ask for approval if exceeding budget.
**Fix:** [Tier 1] Build hard kill-switch if token estimate exceeds budget (ask Denis before proceeding)

### Issue 3: Skill Routing Ambiguity
**Description:** If request is vague, system might route to wrong skill.
**Workaround:** Be specific. "I need cold email" instead of "I need outreach"
**Fix:** [Tier 2] Add skill clarification questions in CLAUDE.md

### Issue 4: Evaluation Subjectivity
**Description:** Quality score (1–10) can vary between raters.
**Workaround:** Use the 4-question framework strictly. Score each question independently.
**Fix:** [Tier 3] Build AI evaluation model (use llm-evaluation skill to auto-score outputs)

### Issue 5: Cross-Project Context Bleed
**Description:** If working on multiple projects, context can accidentally mix.
**Workaround:** Always specify project name upfront. System will load correct context.
**Fix:** Built into system by design (no easy fix, just awareness)

---

## Learnings Log (To Fill In Over Time)

### What Works Well
- [To be filled in after first campaigns] Best-performing cold email angles
- [To be filled in after first campaigns] Which channels deliver lowest cost-per-lead
- [To be filled in after first campaigns] Which message pillars resonate with ICPs
- [To be filled in after first campaigns] Token efficiency (best skills, best batching practices)

### What Doesn't Work
- [To be filled in after first campaigns] Messaging angles that consistently underperform
- [To be filled in after first campaigns] Channels that don't match ICP
- [To be filled in after first campaigns] Batching strategies that don't save tokens

### Unexpected Insights
- [To be filled in after first campaigns]
- [To be filled in after first campaigns]

---

## Quarterly Reviews (Track System Evolution)

### Q2 2026 (April–June)
- [ ] Run 3–5 complete campaigns (research → execution → measurement)
- [ ] Document learnings (winning angles, channels, token efficiency)
- [ ] Evaluate system usability (was it easy to use?)
- [ ] Identify top 3 pain points
- [ ] Plan Q3 improvements

### Q3 2026 (July–September)
- [ ] Implement Tier 2 improvements
- [ ] Add case study library (real examples from campaigns)
- [ ] Refine token budgets based on actual usage
- [ ] Consider AI evaluation module

### Q4 2026 (October–December)
- [ ] Full system audit (what worked, what didn't)
- [ ] Plan 2027 roadmap (major features)
- [ ] Consider open-sourcing or sharing with team

---

## Success Metrics (Track System ROI)

**Track these metrics to evaluate system effectiveness:**

| Metric | Baseline | Target (3 months) | Target (12 months) |
|--------|----------|-------------------|-------------------|
| Time to first campaign | TBD | <2 weeks | <1 week |
| Cost per lead (via cold email) | TBD | <$500 | <$300 |
| Landing page conversion rate | TBD | >5% | >8% |
| Email open rate | TBD | >8% | >12% |
| Tokens spent per $1 revenue | TBD | <100 tokens | <50 tokens |
| System uptime | 100% | 99% | 99.5% |
| User satisfaction | TBD | >8/10 | >9/10 |

---

## Documentation Debt (What's Incomplete)

- [ ] Video walkthroughs for each major workflow
- [ ] Case studies (real examples)
- [ ] Industry-specific examples (SaaS, e-commerce, B2B services)
- [ ] API documentation (if building integrations)
- [ ] Team collaboration guides (how to use if more than 1 person)
- [ ] Troubleshooting guide (common errors + fixes)

---

## Future Vision (12+ Months)

### Phase 2 Features (Planned)
- **Multi-team collaboration** — Share projects, skills, learnings across team
- **Automated campaign orchestration** — Set it and forget it (system runs campaigns automatically)
- **AI-powered positioning** — ML model learns from campaigns, recommends next best angle
- **Real-time bidding** — Adjust ad budgets based on live performance
- **Predictive analytics** — Forecast results before running campaign

### Phase 3 Features (Exploring)
- **Customer data platform (CDP)** — Centralize customer data
- **Revenue attribution** — Track which campaign drove which deal
- **Predictive lead scoring** — Identify highest-probability leads
- **Automated segmentation** — Auto-create audience segments based on behavior

---

## How to Use This Document

### For Denis (Solo User)
- Check this monthly
- Update "Learnings Log" with campaign results
- Flag issues that come up
- Add feature requests as you think of them

### For Team (If Expanded)
- Assign someone to maintain this
- Weekly standup: Review active items
- Monthly: Move completed items to "Done" section
- Quarterly: Archive old issues, plan new roadmap

---

## Archive (Completed)

### Completed (Q1 2026)
- ✅ Create core Marketing OS (all 7 docs)
- ✅ Build skill orchestration matrix
- ✅ Create token optimization config
- ✅ Generate project context template
- ✅ Establish evaluation framework
- ✅ Package for Cowork + Chat + ChatGPT

---

*Marketing OS v1.0 · tasks.md · 2026-04-07*
*Living backlog for the system. Update monthly.*
