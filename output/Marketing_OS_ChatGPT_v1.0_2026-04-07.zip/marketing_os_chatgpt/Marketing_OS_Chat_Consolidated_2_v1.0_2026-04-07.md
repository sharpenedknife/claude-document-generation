# Marketing OS — Skill Orchestration Matrix
**Version:** 1.0
**Date:** 2026-04-07
**Purpose:** Map how all 25+ marketing skills coordinate, hand off work, and reference shared project context.

---

## Overview

The Marketing OS uses **25+ Claude skills** working simultaneously. They're not isolated tools—they orchestrate around a single **project-marketing-context.md** that defines ICP, messaging, positioning, and channels.

**Architecture:**
```
┌─────────────────────────────────────────────────────┐
│   Project-Marketing-Context.md (Shared Nerve Center) │
│   (ICP, Messaging, Positioning, Channels, GTM)       │
└──────────────────┬──────────────────────────────────┘
                   │
        ┌──────────┼──────────┐
        │          │          │
   ┌────▼────┐ ┌──▼──────┐ ┌─▼──────────┐
   │RESEARCH │ │EXECUTION│ │OPTIMIZATION│
   └────┬────┘ └──┬──────┘ └─┬──────────┘
        │         │          │
    [7 Skills]  [15 Skills] [3+ Skills]
```

Each skill reads the project context, pulls relevant data, executes its specialty, outputs work, and feeds into downstream skills.

---

## Phase 1: Research & Strategy (Foundation)

**These skills run FIRST. They create the project-marketing-context.md that all other skills reference.**

| Skill | Input | Output | Token Cost | When to Use |
|-------|-------|--------|------------|-----------|
| **customer-research** | Problem statement, target audience | Customer insights, pain points, quotes, behavior patterns | 2–3K | Starting new project or validating ICP assumptions |
| **conducting-user-interviews** | Interview questions, target participants | Transcripts, themes, quotes, behaviors | 1.5–2K | Primary research (1:1 customer calls) |
| **designing-surveys** | Survey questions, audience | Survey design, analysis framework | 1K | Quantify patterns from interviews |
| **competitive-analysis** | Competitor list, your positioning | Competitive matrix, gaps, opportunities | 1.5–2K | Understanding landscape and positioning |
| **customer-research** (secondary) | Topic (market reports, reviews, forums) | Market trends, competitor intel, customer language | 2K | G2 analysis, Reddit mining, market reports |
| **brand-storytelling** | Your origin, values, mission | Brand story, voice guide, narrative arc | 1–1.5K | Define brand identity |
| **defining-product-vision** | Long-term goals, market opportunity | Vision statement, product direction | 1K | Strategic alignment |

**Output:** **project-marketing-context.md** (feeds all downstream skills)

**Quality Gate:** Context doc is complete, ICP data-driven, messaging tested, channels prioritized.

---

## Phase 2: Execution (All Skills Simultaneously)

**These skills pull from project-marketing-context.md and execute campaigns, content, and outreach.**

### Messaging & Content Foundation
| Skill | Input | Output | Token Cost | Downstream |
|-------|-------|--------|------------|-----------|
| **copywriting** | Messaging pillars, ICP, context | Website copy, landing pages, long-form content | 1.5–2K | All paid/owned channels |
| **brand-storytelling** (applied) | Brand narrative, voice | Positioning pages, about pages, case studies | 1–1.5K | Content, social, brand assets |

### Cold Outbound (Highest ROI)
| Skill | Input | Output | Token Cost | Downstream |
|-------|-------|--------|------------|-----------|
| **cold-email** | ICP, messaging, list | Email sequences (initial + 3–5 follow-ups), templates | 1.5–2.5K | Analytics-tracking (measure opens/clicks) |
| **founder-sales** | ICP, messaging, objection handling | Sales call framework, demo deck, pitch guide | 1–1.5K | Sales team, live meetings |
| **email-sequence** | Cold email output, nurture sequence | Full automated sequence (5–10 emails), timing, CTAs | 1.5–2K | Analytics-tracking, conversion measurement |

### Content & Owned Channels
| Skill | Input | Output | Token Cost | Downstream |
|-------|-------|--------|------------|-----------|
| **content-strategy** | ICP, messaging pillars, channels | Content calendar, topic clusters, keywords | 1–1.5K | copywriting, content-marketing |
| **content-marketing** | Topics, target audience | Blog post outlines, SEO strategy, distribution plan | 1.5–2K | copywriting, ai-seo (for AI visibility) |
| **ai-seo** | Blog content, positioning | AI search optimization, LLM citation opportunities | 1K | Publishing, promotion |

### Paid & Creative Channels
| Skill | Input | Output | Token Cost | Downstream |
|-------|-------|--------|------------|-----------|
| **ad-creative** | Messaging pillars, ICP, brand voice | Ad copy variations (5–20), headlines, CTAs | 1.5–2K | Analytics-tracking (CTR, conversion) |
| **copywriting** (landing pages) | Messaging, ICP, offer | High-converting landing page copy | 1.5–2K | form-cro (optimize form fields) |
| **form-cro** | Landing page, lead magnet | Optimized form fields, field order, copy | 1K | Analytics-tracking (form completion rate) |

### Website & Sales Enablement
| Skill | Input | Output | Token Cost | Downstream |
|-------|-------|--------|------------|-----------|
| **competitor-alternatives** | Your positioning, competitors | Alternative/vs. pages for SEO + sales | 1–1.5K | Publishing, sales deck |
| **copywriting** (sales pages) | Positioning, objections, proof | Pricing page, feature pages, case studies | 1–1.5K | Sales, conversion measurement |

### Social & Community
| Skill | Input | Output | Token Cost | Downstream |
|-------|-------|--------|------------|-----------|
| **community-building** | ICP, messaging, channels | Community strategy, Discord/Slack setup, engagement plan | 1.5K | Organic growth, word-of-mouth |
| **content-strategy** (social angle) | Brand voice, platforms | Social content calendar, thread templates | 1K | Publishing, engagement |

### Copy Polish
| Skill | Input | Output | Token Cost | Downstream |
|-------|-------|--------|------------|-----------|
| **copy-editing** | Draft copy from any source | Polished, tight copy (removes 20–30% of words) | 0.5–1K | Publishing, performance |

---

## Phase 3: Measurement & Optimization (Continuous)

**These skills measure performance, run tests, and feed learnings back into strategy.**

| Skill | Input | Output | Token Cost | Loop Back To |
|-------|-------|--------|------------|-------------|
| **analytics-tracking** | Campaigns, conversion points, goals | Tracking plan, GTM implementation, dashboard | 1–1.5K | All campaigns (measures performance) |
| **ab-test-setup** | Hypotheses (copy, creative, offer) | Test framework, variants, sample size, timeline | 1–1.5K | copywriting, ad-creative, form-cro |
| **designing-surveys** | Post-purchase or churn questions | Survey design, analysis framework | 1K | customer-research (feedback loop) |
| **churn-prevention** | ICP, objections, retention metrics | Exit survey, save offers, win-back sequence | 1.5K | email-sequence, copywriting (adjust messaging) |
| **designing-growth-loops** | Current metrics, virality potential | Referral mechanics, network effects, expansion strategy | 1.5K | Marketing strategy, customer-research (feedback) |

---

## Orchestration Workflows

### Workflow 1: Cold Outbound Campaign (Fastest ROI)
**Timeline:** 2–3 weeks
**Skills Used:** 5 (research → outbound → measure)

```
1. product-marketing-context.md exists ✓
   ↓
2. cold-email (writes sequence)
   ↓
3. founder-sales (sales call framework if warm)
   ↓
4. analytics-tracking (sets up opens/clicks/reply tracking)
   ↓
5. ab-test-setup (test 2 subject lines, 2 opening hooks)
   ↓
6. MEASURE: Reply rate, conversion rate
   ↓
7. LEARN: Update messaging if needed, iterate
```

**Token Budget:** ~6–8K total (one-time per campaign)

---

### Workflow 2: Content & SEO Funnel (Long-term)
**Timeline:** 4–8 weeks
**Skills Used:** 6 (strategy → content → SEO → measure)

```
1. product-marketing-context.md exists ✓
   ↓
2. content-strategy (topic clusters, keywords)
   ↓
3. copywriting (blog post outlines, copy)
   ↓
4. ai-seo (optimize for AI search engines)
   ↓
5. analytics-tracking (organic traffic, lead gen)
   ↓
6. ab-test-setup (test headlines, CTAs, offers)
   ↓
7. MEASURE: Traffic, leads, conversion rate
   ↓
8. LEARN: Double down on winning topics, kill underperformers
```

**Token Budget:** ~8–12K total (amortized across multiple posts)

---

### Workflow 3: Paid Ads Campaign
**Timeline:** 1–2 weeks
**Skills Used:** 5 (creative → execution → optimize)

```
1. product-marketing-context.md exists ✓
   ↓
2. ad-creative (write 10+ variations)
   ↓
3. copywriting (landing pages for each ad)
   ↓
4. form-cro (optimize lead capture form)
   ↓
5. analytics-tracking (impressions, clicks, conversions)
   ↓
6. ab-test-setup (test 3 creatives, 2 audiences)
   ↓
7. MEASURE: CTR, conversion rate, cost per lead
   ↓
8. LEARN: Pause losers, scale winners, iterate
```

**Token Budget:** ~6–8K total (per campaign)

---

### Workflow 4: Full-Funnel Launch (All Phases)
**Timeline:** 6–12 weeks
**Skills Used:** 15+ (research → awareness → consideration → decision → measure)

```
RESEARCH PHASE (Weeks 1–2):
├─ customer-research
├─ competitive-analysis
├─ brand-storytelling
└─ Output: project-marketing-context.md

AWARENESS PHASE (Weeks 3–4):
├─ content-strategy
├─ copywriting
├─ ad-creative
└─ cold-email (warm outreach)

CONSIDERATION PHASE (Weeks 5–6):
├─ email-sequence (nurture)
├─ copywriting (case studies, comparison pages)
├─ competitor-alternatives (vs. pages)
└─ form-cro (lead capture)

DECISION PHASE (Weeks 7+):
├─ founder-sales (sales calls)
├─ copywriting (pricing, objection handling)
└─ churn-prevention (retention)

OPTIMIZATION (Ongoing):
├─ analytics-tracking (all phases)
├─ ab-test-setup (test winning angles)
├─ designing-surveys (customer feedback)
└─ designing-growth-loops (expansion)
```

**Token Budget:** ~25–35K total (amortized across 6+ months)

---

## Token Allocation by Phase

| Phase | Skills | % of Budget | Typical Spend |
|-------|--------|------------|---------------|
| Research & Strategy | 7 skills | 15% | 4–6K (one-time) |
| Execution | 15 skills | 55% | 12–18K (per month) |
| Measurement & Optimization | 3+ skills | 20% | 4–6K (per month) |
| Iteration & Learning | All | 10% | 2–3K (per month) |

**Total Monthly Budget:** ~20–30K tokens (varies by campaign intensity)

---

## Skill Dependencies & Sequencing

```
Must Run Before Others:
├─ product-marketing-context.md (all others depend on this)
├─ customer-research (informs positioning)
├─ competitive-analysis (informs positioning)
└─ brand-storytelling (informs all messaging)

Then Can Run Simultaneously:
├─ Execution Group: cold-email, copywriting, ad-creative, content-strategy
└─ Support Group: form-cro, analytics-tracking, ab-test-setup

Finally:
└─ Optimization: churn-prevention, designing-surveys, designing-growth-loops
```

---

## Skill Routing Rules (Token Efficiency)

**Rule 1: Reuse Project Context**
- product-marketing-context.md is loaded ONCE per project
- All 15+ execution skills reference the same context
- Don't re-run research unless ICP changes
- **Token Savings:** ~10K per project

**Rule 2: Batch Similar Tasks**
- Instead of: "Write one cold email" (costs 1.5K)
- Do: "Write 5 cold email variations + 3 follow-ups" (costs 2.5K for all)
- **Token Savings:** ~30–40% per task type

**Rule 3: Skip Polish for Drafts**
- Use copywriting for first drafts
- Skip copy-editing for internal iterations
- Only polish for publication
- **Token Savings:** ~0.5K per draft cycle

**Rule 4: Conditional Skill Triggers**
- If cold email reply rate is good: skip ab-test-setup
- If landing page converting: don't run form-cro
- If no churn signal: skip churn-prevention
- **Token Savings:** ~2–3K per campaign

**Rule 5: Async Skill Execution**
- Run research skills first (4–6K)
- Then execution skills in parallel (not sequential)
- Measure continuously
- **Token Efficiency:** Linear token growth, not exponential

---

## Quality Gates at Each Stage

### After Research Phase (Gate 1)
- [ ] project-marketing-context.md created and current
- [ ] ICP data-driven (from customer research, not guesses)
- [ ] Positioning tested against competitive landscape
- [ ] Messaging tied to customer language
- [ ] Channels prioritized by audience + cost

### After Each Execution Skill (Gate 2)
- [ ] Output quality: Does it match messaging pillars?
- [ ] Does it speak to ICP in their language?
- [ ] Does it address stated objections?
- [ ] Is it differentiated from competitors?

### After Campaign Launch (Gate 3)
- [ ] Tracking is live (analytics-tracking confirmed)
- [ ] Test variants are distinct (ab-test-setup confirmed)
- [ ] Baseline metrics captured
- [ ] Success thresholds defined

### During Optimization (Gate 4)
- [ ] Learnings from each campaign logged
- [ ] Successful angles fed back to copywriting, ad-creative
- [ ] Failed approaches documented (prevent re-iteration)
- [ ] project-marketing-context.md updated with learnings

---

## Evaluation Framework (Manual Review Loop)

**Question 1: Does it match the ICP?**
- Read the output
- Check against project-marketing-context.md
- Ask: "Would THIS ICP person respond to this?"
- Score 1–10

**Question 2: Does it use customer language?**
- Are your actual customer quotes/phrases in the copy?
- Or is it generic marketing speak?
- Score 1–10

**Question 3: Is it differentiated?**
- Read competitor copy
- Compare your copy
- Ask: "Could this ONLY come from our company?"
- Score 1–10

**Question 4: Does it address objections?**
- List common objections for this ICP
- Check if copy proactively addresses them
- Score 1–10

**Quality Threshold:** Average score ≥7/10. Below 7 = revise before publishing.

---

## Skill Selection Matrix (Which Skill for This Task?)

| Task | Skill | Why | Token Cost | When NOT to Use |
|------|-------|-----|------------|-----------------|
| "Write landing page copy" | copywriting | Comprehensive, ICP-focused | 1.5–2K | If just need minor tweaks (use copy-editing) |
| "Polish existing copy" | copy-editing | Fast, efficient, tightens | 0.5–1K | If starting from scratch (use copywriting) |
| "Write 5 cold email versions" | cold-email | Specialized in outbound, personalization | 1.5–2K | If not B2B outbound (use copywriting) |
| "Create email drip sequence" | email-sequence | Lifecycle, timing, automation | 1.5–2K | If just one email (use copywriting) |
| "Understand customer problems" | customer-research | Synthesizes interviews, reviews, data | 2–3K | If already have clear ICP (save tokens) |
| "Understand competitors" | competitive-analysis | Positioning, gaps, war games | 1.5–2K | If only need quick feature comparison |
| "Build content strategy" | content-strategy | Topic clusters, keywords, editorial cal | 1–1.5K | If already have a list (use copywriting) |
| "Measure campaign performance" | analytics-tracking | Implementation, dashboard, GTM | 1–1.5K | If already tracking (just pull data) |
| "Design A/B test" | ab-test-setup | Hypothesis, variants, sample size | 1–1.5K | If test is trivial (manual quickstart) |

---

## Example: Multi-Skill Campaign (Cold Outbound)

**Project:** Launch outbound to VP Marketing at mid-market SaaS
**Timeline:** 2 weeks
**Budget:** 8K tokens

**Day 1:**
- **Input:** project-marketing-context.md (ICP = VP Marketing, mid-market SaaS, pain = manual reporting)
- **Skill:** cold-email
- **Output:** 5-email sequence (initial + 3 follow-ups) + personalization framework
- **Token Cost:** 2K
- **Quality Check:** Does each email address their pain? Use their language? Stand out from 50 other emails they get?

**Day 2:**
- **Input:** Cold email sequence from Day 1
- **Skill:** founder-sales (craft sales call framework for warm intros)
- **Output:** Sales call script, objection handling, demo flow
- **Token Cost:** 1.2K

**Day 3:**
- **Input:** Campaign IDs, email addresses
- **Skill:** analytics-tracking (set up open, click, reply tracking)
- **Output:** Tracking implementation, success dashboards
- **Token Cost:** 1K

**Day 4–5:**
- **Input:** Initial email + 2 variations
- **Skill:** ab-test-setup (test subject line + opening hook)
- **Output:** Test design, sample size, success thresholds
- **Token Cost:** 1.2K

**Day 6–14:**
- **Execution:** Send sequence, measure, iterate
- **Skill:** designing-surveys (exit survey if they unsubscribe: "What was the objection?")
- **Token Cost:** 0.8K

**Learnings Loop:**
- **Input:** Reply rate (15%), objection themes (budget concerns)
- **Skill:** copywriting (update cold email to address budget objection)
- **Output:** Revised email sequence v2
- **Token Cost:** 1.2K (amortized across next batch)

**Total:** ~8K tokens for a full cold outbound campaign with measurement + optimization.

---

## Preventing Token Creep

**Anti-Pattern 1: Re-running research for every campaign**
- Fix: Reuse project-marketing-context.md
- Save: 4–6K tokens per campaign

**Anti-Pattern 2: Sequential skill execution (waiting for each output)**
- Fix: Run execution skills in parallel
- Save: 10–20% time, not token-specific but faster feedback

**Anti-Pattern 3: Over-iterating on polish**
- Fix: Skip copy-editing drafts, only polish for publication
- Save: 0.5K per draft cycle × 5 cycles = 2.5K per project

**Anti-Pattern 4: Using wrong skill for task**
- Fix: Use the skill selection matrix above
- Save: 0.5–1.5K per task (using efficient skill)

**Anti-Pattern 5: Not documenting learnings**
- Fix: Log winning angles, objections, customer language in project context
- Save: Avoid re-learning the same lessons (2–3K per mistake avoided)

---

*Marketing OS v1.0 · Skill Orchestration Matrix · 2026-04-07*
*Reference for token efficiency, skill routing, and campaign workflows*
# Marketing OS — Token Optimization Config
**Version:** 1.0 | **Date:** 2026-04-07 | **Purpose:** Hard token budgets, efficiency rules, and cost tracking

---

## Monthly Token Budget (20–30K tokens/month)

**Total Budget:** 25K tokens/month (baseline)

| Phase | Budget % | Token Cap | Monthly Spend |
|-------|----------|-----------|---------------|
| Research & Strategy | 15% | 3.75K | Once per project ($0 on ongoing) |
| Execution (Content, Outbound, Ads) | 55% | 13.75K | 13.75K/month |
| Measurement & Optimization | 20% | 5K | 5K/month |
| Iteration & Learning | 10% | 2.5K | 2.5K/month |
| **TOTAL** | 100% | 25K | 25K/month |

**Flexibility:** If campaign is performing well, reduce optimization. If testing new angle, increase execution.

---

## Phase 1: Research & Strategy (One-Time Cost)

These budgets apply **per project**. Don't re-run unless ICP changes.

| Task | Skill | Cost | Max per Project |
|------|-------|------|-----------------|
| Customer interviews analysis | customer-research | 2–3K | 3K (run once per project) |
| Competitive analysis | competitive-analysis | 1.5–2K | 2K (run once per project) |
| Brand storytelling | brand-storytelling | 1–1.5K | 1.5K (run once per project) |
| **TOTAL per new project** | | | **6–6.5K** |
| **After project established** | | | **$0** (reuse context) |

**Rule:** If you're starting a new project, budget 6–6.5K upfront. For months 2+ on that project, you've already paid this cost (one-time).

**Token Savings Example:**
- Month 1, Project A: Research = 6.5K tokens
- Month 2, Project A: NO research (reuse context) = 0K tokens saved
- Month 2, Project B (new): Research = 6.5K tokens
- Total for Month 2: 6.5K (new project) vs. 13K (if you re-researched Project A)
- **Savings: 6.5K tokens**

---

## Phase 2: Execution (Per Campaign)

These budgets apply **per campaign** on an existing project (context already built).

### Outbound/Cold Email Campaigns

| Task | Skill | Input | Output | Cost |
|------|-------|-------|--------|------|
| Write cold email sequence (1 variation) | cold-email | ICP + messaging | 1 email + follow-ups | 1.5K |
| Write cold email batch (5 variations) | cold-email | ICP + messaging | 5 emails + follow-ups | 2.5K |
| Sales call prep | founder-sales | Objections, ICP | Sales script + demo | 1K |
| Nurture sequence | email-sequence | Cold email output | 5–10 emails | 1.5–2K |
| **Outbound Campaign (Full)** | All above | | All deliverables | **6–7K** |

**Token Saving:** Batch 5 variations = 2.5K vs. 1 variation × 5 = 7.5K. **Saves 5K tokens.**

---

### Content Marketing Campaigns

| Task | Skill | Cost | Output |
|------|-------|------|--------|
| Content strategy (topic cluster) | content-strategy | 1–1.5K | Editorial calendar, topic list, keywords |
| Blog post copy (1 post) | copywriting | 1.5–2K | 2000–3000 word post with SEO |
| Blog post + SEO optimization | copywriting + ai-seo | 2.5–3K | Blog + AI visibility optimization |
| Content series (5 posts) | content-marketing | 2–3K | 5 posts coordinated, distribution plan |
| **Content Campaign (Full)** | All above | **5–7K** | Full content strategy + initial posts |

---

### Paid Ads Campaigns

| Task | Skill | Cost | Output |
|------|-------|------|--------|
| Ad creative (single variant) | ad-creative | 1.5K | 1 complete ad (headline, body, image) |
| Ad creative (batch, 5–10 variants) | ad-creative | 2–2.5K | 5–10 ad variations ready to test |
| Landing page copy | copywriting | 1.5–2K | Full landing page (hero to CTA) |
| Form optimization | form-cro | 1K | Optimized form fields, copy, order |
| **Paid Campaign (Full)** | All above | **6–8K** | Ad creatives + landing page + optimizations |

---

### Bundled Campaign (Multi-Channel)

| Approach | Cost | What You Get |
|----------|------|--------------|
| Outbound Only | 6–7K | Cold email sequence + sales prep + nurture |
| Content Only | 5–7K | Strategy + 2–3 blog posts + SEO optimization |
| Paid Only | 6–8K | Ad creative (5+ variants) + landing page |
| Outbound + Content | 12–14K | Outbound (6–7K) + Content (5–7K) |
| Outbound + Paid | 12–15K | Outbound (6–7K) + Paid (6–8K) |
| **Content + Paid** | **12–15K** | Content (5–7K) + Paid (6–8K) |
| **Full Funnel (All 3)** | **18–22K** | Outbound + Content + Paid (run in sequence) |

**Monthly Recommendation:** Pick 1–2 channels to start. Measure for 2 weeks. Double down on winner.

---

## Phase 3: Measurement & Optimization (Per Campaign)

| Task | Skill | Cost | When to Use |
|------|-------|------|-----------|
| Analytics setup (tracking implementation) | analytics-tracking | 1–1.5K | ONCE per campaign (upfront) |
| A/B test design (2 variants, 100+ sample size) | ab-test-setup | 1–1.5K | Every 2 weeks (ongoing) |
| Customer feedback survey | designing-surveys | 0.5–1K | Monthly |
| Growth loop design | designing-growth-loops | 1.5K | Quarterly review |
| Churn prevention strategy | churn-prevention | 1.5K | When churn detected |
| **Monthly Optimization** | | **3–5K** | Ongoing |

**Rule:** Budget 5K/month for measurement + testing. This drives learnings that feed back into strategy.

---

## Phase 4: Iteration & Learning (2.5K/month)

This budget covers revision cycles, not new campaigns.

| Activity | Cost | When |
|----------|------|------|
| Revise copy based on feedback | copy-editing | 0.5–1K | After evaluation, below 7/10 |
| Update email based on test results | copywriting (revision) | 1–1.5K | Week 2 of campaign (pivot if needed) |
| Rewrite landing page based on conversion data | copywriting (revision) | 1–1.5K | After 100 visitors (if <5% conversion) |

**Rule:** Don't exceed 2.5K/month on revisions. If revisions are needed, it's usually a messaging problem (update project context instead).

---

## Token Allocation Example (Typical Month)

### Scenario: Month 1 — New Project

```
Research Phase (Week 1): 6.5K
├─ customer-research: 3K
├─ competitive-analysis: 2K
└─ brand-storytelling: 1.5K
└─ Output: project-marketing-context.md

Execution Phase (Weeks 2–3): 8K
├─ Cold Email Campaign: 3K
│  ├─ cold-email (5 variations): 2.5K
│  └─ email-sequence (nurture): 1.5K
└─ Paid Ads Campaign: 5K
   ├─ ad-creative (10 variants): 2.5K
   └─ copywriting (landing page): 2.5K

Measurement Phase (Week 4): 3K
├─ analytics-tracking: 1.5K
├─ ab-test-setup (email subject lines): 1K
└─ designing-surveys: 0.5K

Iteration & Learning (Ongoing): 2K
├─ Revisions based on feedback: 1.5K
└─ Project context updates: 0.5K

TOTAL MONTH 1: 19.5K tokens
(Below 25K budget — good)
```

### Scenario: Month 2 — Ongoing Project (Scale Winner)

```
Execution Phase (Weeks 1–4): 12K
├─ Double-down cold outbound: 5K
│  ├─ cold-email (10 variants, new angles): 3K
│  └─ email-sequence (longer nurture): 2K
└─ Content marketing: 7K
   ├─ content-strategy (new topic cluster): 1.5K
   └─ Blog series (4 posts): 5.5K

Measurement Phase (All month): 4K
├─ analytics-tracking (expanded): 1.5K
├─ ab-test-setup (weekly tests): 1.5K
└─ designing-surveys (mid-campaign feedback): 1K

Iteration & Learning (Ongoing): 2K
├─ Optimize winning email angle: 1K
└─ Adjust landing page based on data: 1K

TOTAL MONTH 2: 18K tokens
(Leaves 7K buffer for new project research if needed)
```

---

## Token Efficiency Rules (Prevent Creep)

### Rule 1: Batch Tasks (Save 25–30%)
**Instead of:** Ask for 1 email 5 times = 1.5K × 5 = 7.5K
**Do:** Ask for 5 emails at once = 2.5K total
**Savings:** 5K tokens

### Rule 2: Reuse Project Context (Save 6.5K)
**Instead of:** Re-run research for every campaign = 6.5K per campaign
**Do:** Load existing project-marketing-context.md = $0 per campaign
**Savings:** 6.5K tokens (per month, per project)

### Rule 3: Skip Polish for Drafts (Save 0.5K)
**Instead of:** copywriting + copy-editing = 1.5K + 0.5K = 2K
**Do:** Use copywriting for drafts, skip editing = 1.5K. Only edit for publication.
**Savings:** 0.5K per draft iteration

### Rule 4: Conditional Skill Triggers (Save 1–3K)
**Instead of:** Run ab-test-setup for every campaign
**Do:** Test only if metric is unclear. Skip if winning.
**Savings:** 1–1.5K per campaign where testing isn't needed

### Rule 5: Async Execution (Save Time, not tokens, but efficiency matters)
**Instead of:** Run skills sequentially (research → copy → ads → measurement)
**Do:** Run research, then execution skills in parallel, then measurement
**Benefit:** Faster feedback loop, faster iteration

---

## Monthly Token Tracking Template

| Week | Activity | Skill(s) | Cost | Running Total | Status |
|------|----------|----------|------|---------------|--------|
| Week 1 | [Campaign name] | [Skill] | [Cost] | [Total] | On track |
| Week 2 | [Campaign name] | [Skill] | [Cost] | [Total] | On track |
| Week 3 | [Campaign name] | [Skill] | [Cost] | [Total] | On track / Over / Under |
| Week 4 | [Campaign name] | [Skill] | [Cost] | [Total] | FINAL |

**At end of month:**
- Did you stay under 25K? ✓
- Which activities were most costly?
- Which skills were most efficient?
- Where can you optimize next month?

---

## When to Increase/Decrease Budget

### Increase Budget If:
- Campaign is performing well (reply rate 15%+, conversion 5%+)
- You want to test new channels (add $5–10K for experimentation)
- You're scaling a proven angle (double down on what works)
- New project launched (research costs 6–7K upfront)

### Decrease Budget If:
- Campaign is underperforming (reply rate <5%, conversion <2%)
- You hit monthly targets early (pause and optimize)
- Budget is tight (prioritize highest-ROI channels)

---

## Cost Per Outcome (ROI Thinking)

**Cold Email Campaign:**
- Cost: 3K tokens
- Effort: 2 weeks
- Outcome: 50–100 email conversations, 5–10 qualified leads
- **Cost per lead: 300–600 tokens**

**Content Campaign (Blog Series):**
- Cost: 5.5K tokens
- Effort: 4 weeks
- Outcome: 1000+ organic impressions, 10–20 qualified leads (long-tail)
- **Cost per lead: 275–550 tokens**

**Paid Ads Campaign:**
- Cost: 5K tokens (execution only, not media spend)
- Effort: 2 weeks
- Outcome: 100–500 clicks, 5–25 qualified leads
- **Cost per lead: 200–1000 tokens** (highly variable by CPC)

**Analysis:** Cold email often has best ROI. Content has longest tail. Ads are variable.

---

## Quarterly Review Checklist

Every 3 months, review token usage and optimize:

- [ ] Which skills were used most? (Most valuable?)
- [ ] Which campaigns had highest ROI (lowest tokens per lead/sale)?
- [ ] Which projects were most efficient?
- [ ] Where did you exceed budget? (Why?)
- [ ] Where did you save tokens? (Replicate it next quarter?)
- [ ] Did batching actually save tokens? (Track it)
- [ ] Are there new skills to test?
- [ ] Should you increase/decrease monthly budget?

---

*Marketing OS v1.0 · Token Optimization Config · 2026-04-07*
*Hard budgets, efficiency rules, cost tracking. Use monthly.*
# Marketing OS — Setup Guide
**Version:** 1.0 | **Date:** 2026-04-07 | **Purpose:** How to activate and use the Marketing OS in Claude.ai and Cowork

---

## Quick Start (5 Minutes)

### Step 1: Load This Project in Claude.ai
1. Go to **Claude.ai → Projects**
2. Create new project: "Marketing OS"
3. Add these docs to project context:
   - MARKETING_OS_CLAUDE_v1.0.md (Custom instructions)
   - MARKETING_OS_SkillOrchestration_Matrix_v1.0.md (Skill routing)
   - MARKETING_OS_KnowledgeStructure_v1.0.md (Templates)

### Step 2: Create Your First Project Context
1. Make a new file: `[ProjectName]_marketing.md`
2. Use the template: **MARKETING_OS_ProjectContext_Template_v1.0.md**
3. Fill in: ICP, messaging, positioning, channels
4. Upload to project

### Step 3: Run Your First Campaign
1. Say: "I want to run a cold email campaign for [Project Name]"
2. System will load your context
3. Route to **cold-email** skill
4. Deliver email sequence
5. Evaluate (score it 1–10)
6. Ship or revise

---

## Installation (15 Minutes)

### Option A: Claude.ai Projects (Recommended)

**Step 1: Create Claude Project**
```
Claude.ai → Projects → New Project → "Marketing OS"
```

**Step 2: Add Core Docs (Project Instructions)**
Upload these 3 files to project context:
```
✅ MARKETING_OS_CLAUDE_v1.0.md
✅ MARKETING_OS_SkillOrchestration_Matrix_v1.0.md
✅ MARKETING_OS_KnowledgeStructure_v1.0.md
```

**Step 3: Add Reference Docs (Knowledge Base)**
Upload these as optional context (users can reference):
```
📖 MARKETING_OS_Research_GTM_Framework_v1.0.md
📖 MARKETING_OS_ProjectContext_Template_v1.0.md
📖 MARKETING_OS_Instructions_v1.0.md
📖 MARKETING_OS_TokenOptimization_v1.0.md
📖 MARKETING_OS_SetupGuide_v1.0.md (this file)
```

**Step 4: Test**
- Open the project
- Say: "I want to build project context for [YourCompany]"
- System should acknowledge and ask for Tier 1 context (ICP + channels)

---

### Option B: Cowork Mode (For Solo Use)

**Step 1: Folder Structure**
```
/agents/
├── CLAUDE.md (use MARKETING_OS_CLAUDE_v1.0.md)
├── project_marketing_context.md (create per project)
└── REFERENCE/ (optional reference docs)
    ├── MARKETING_OS_SkillOrchestration_Matrix.md
    ├── MARKETING_OS_KnowledgeStructure.md
    ├── tasks.md
    └── [other reference docs]
```

**Step 2: Copy Files**
- Move all MARKETING_OS_*.md files to your Cowork workspace
- Create `/agents/` folder
- Add custom instructions (CLAUDE.md)

**Step 3: Create Project Contexts**
- For each client/project, create: `[ProjectName]_marketing.md`
- Use the template
- Store in `/agents/` or `/projects/` folder

**Step 4: Reference in Cowork**
- Tell Claude: "My marketing system is in [Folder]"
- Claude loads context automatically

---

## First-Time Setup Checklist

- [ ] Decided: Claude.ai Projects OR Cowork mode?
- [ ] Created project/workspace
- [ ] Added CLAUDE.md (custom instructions)
- [ ] Added Skill Orchestration Matrix (reference)
- [ ] Added Knowledge Structure (templates)
- [ ] Created first project context file ([ProjectName]_marketing.md)
- [ ] Filled in: ICP, messaging, positioning (Tier 1 minimum)
- [ ] Tested: Asked Claude to route a skill
- [ ] Evaluated: First output scored 7+/10?

---

## Using the System (Daily Workflow)

### Morning Ritual (5 minutes)
1. Open Marketing OS project in Claude
2. Ask: "What's my status this week for [Project]?"
3. Claude loads project context
4. Review: What campaigns are live? What metrics came in overnight?

### Campaign Execution (1–2 hours)
1. Decide: What do I need? (copy, cold email, strategy, measurement?)
2. Describe request to Claude: "I need [outcome]"
3. Claude routes skill + estimates tokens
4. You approve or adjust scope
5. Claude executes
6. You evaluate (7+/10?) and ship or revise

### Weekly Review (30 minutes)
1. Open Marketing OS
2. Ask: "Summarize this week's campaign performance for [Project]"
3. Claude pulls metrics, highlights wins/losses
4. Ask: "What should we test next?"
5. Update project context with learnings

### Monthly Planning (1 hour)
1. Ask: "Plan next month for [Project]"
2. Claude:
   - Reviews current metrics
   - Suggests which channels/angles to scale
   - Recommends new experiments
   - Allocates token budget
3. You approve plan
4. Claude creates execution checklist

---

## Common Workflows

### Workflow 1: "I Need Copy"

**You say:** "I need landing page copy for [Project]"

**System does:**
1. Loads [Project]_marketing.md
2. Routes to **copywriting** skill
3. Asks: Scope? (Home page, pricing page, feature page?)
4. Estimates tokens (1.5–2K)
5. Executes copy
6. Evaluates (ICP match? Messaging alignment? Objection handling?)
7. Delivers: Draft + quality score + revision suggestions

**You do:** Review copy, approve, or ask for revision

---

### Workflow 2: "I Need a Cold Email Campaign"

**You say:** "Run cold email campaign for [Project]"

**System does:**
1. Loads [Project]_marketing.md
2. Routes to **cold-email** skill
3. Asks: How many variations? (1, 5, 10?)
4. Asks: Which ICP segment? (All, or specific company size?)
5. Estimates tokens (1.5–2.5K)
6. Executes: 5 email variations + 3 follow-ups
7. Also routes to **email-sequence** skill (nurture path)
8. Also routes to **analytics-tracking** (measurement setup)
9. Evaluates quality
10. Delivers: Full email sequence + tracking setup

**You do:** Copy emails, launch campaign, monitor replies

---

### Workflow 3: "I Need Strategy"

**You say:** "I'm starting a new project: [Description]"

**System does:**
1. Asks Tier 1 questions: "What's your ICP? What channels?"
2. Routes to **customer-research** + **competitive-analysis** (if needed)
3. Routes to **brand-storytelling** (if brand unclear)
4. Synthesizes into: [ProjectName]_marketing.md
5. Delivers: Complete project context ready for execution

**You do:** Provide research, approve context, start campaigns

---

### Workflow 4: "I Need Measurement"

**You say:** "Set up tracking for [Campaign Name]"

**System does:**
1. Loads campaign context
2. Routes to **analytics-tracking** skill
3. Asks: What events to track? (Opens, clicks, conversions?)
4. Sets up tracking implementation (what to measure, where, how)
5. Creates dashboard spec (metrics to watch weekly)
6. Estimates: 1–1.5K tokens

**You do:** Implement tracking in your platform

---

## How to Update Project Context

**When to update:**
- After 1 week of campaign data (learnings)
- After customer research (new ICP insights)
- When competitive landscape shifts
- When messaging tests reveal winning angles

**How to update:**
1. Open [ProjectName]_marketing.md
2. Find section to update (ICP, messaging, channels, etc.)
3. Revise with new data
4. Save
5. Tell Claude: "I updated [ProjectName] context. Use it for next campaign."

**Example:**
> "After running cold emails, I discovered VP Marketers respond 25% better to [specific angle]. Update messaging pillar #2?"
> Claude: "Done. Updated [Project]_marketing.md. Next campaign will emphasize [angle]."

---

## Evaluating Quality (When to Publish vs. Revise)

**After Claude executes any skill output (email, copy, strategy):**

### Quick Evaluation (30 seconds)
- Does it feel right? (Gut check)
- Does it match the ICP? (Quick scan)
- Would I send/publish this? (Honest answer)

### Full Evaluation (2 minutes)
Score on 4 questions:
1. **ICP Match (1–10):** Does it speak to my customer in their language?
2. **Messaging (1–10):** Does it hit my message pillars?
3. **Differentiation (1–10):** Is this unique to my company?
4. **Objections (1–10):** Does it address common concerns?

Average score = Quality Score
- **7–10:** Ready to publish
- **5–6:** Decent, but could be better (ask for revision)
- **1–4:** Missing something critical (revise)

---

## Token Budget Tracking

### Weekly Check-In
```
Q: How many tokens have I used this week?
A: [Claude pulls usage from past week]

Q: Am I on track for my 25K monthly budget?
A: [Math: weekly usage × 4 weeks = projected monthly]
```

### Monthly Review
```
Q: Summary of token usage for [Month]?
A: [Shows breakdown: Research 2K, Execution 12K, Measurement 4K, Iteration 2K = 20K total]

Q: What was most expensive?
A: [Execution phase, cold email + content]

Q: Can I optimize?
A: [Yes: batch more tasks, skip editing drafts, reuse context]
```

---

## Troubleshooting

### Problem: "Claude doesn't know my project context"
**Solution:** Make sure project file is in project (Claude.ai) or loaded in system prompt (Cowork)

### Problem: "Claude is routing to wrong skill"
**Solution:** Be more specific. Say: "I need a cold email, not general copywriting"

### Problem: "Output quality is below 7/10"
**Solution:** Check if ICP is clear in context. Usually a messaging problem, not skill problem.

### Problem: "Tokens are running high"
**Solution:** Batch tasks (5 emails instead of 1), skip polish for drafts, reuse context

### Problem: "I want to switch projects"
**Solution:** Say: "Switch to [Project B context]" and Claude will load it

---

## Advanced: Custom Skills & Integrations

### Adding New Skills
The system uses 25+ built-in marketing skills. If you need something custom:
1. Document the workflow
2. Add to tasks.md as "Future Enhancement"
3. Create custom prompt in CLAUDE.md

### Connecting to Tools
- **CRM (HubSpot, Pipedrive):** Use analytics-tracking + form-cro
- **Email Platform (Mailchimp, ConvertKit):** Use email-sequence skill
- **Ad Platform (LinkedIn, Facebook):** Use ad-creative + analytics-tracking
- **Website (Webflow, WordPress):** Use copywriting + form-cro

---

## Monthly Cadence

### Week 1: Planning
- Review last month's metrics
- Plan this month's campaigns
- Update project contexts with learnings

### Week 2: Execution
- Run primary campaigns (outbound, content, ads)
- Set up tracking
- Monitor early metrics

### Week 3: Optimization
- A/B test winning angles
- Pause underperformers
- Run follow-up campaigns

### Week 4: Analysis & Planning
- Full review of month's results
- Document learnings in project context
- Plan next month

---

## One-Pager: System Architecture

```
Claude Project (Marketing OS)
├── CLAUDE.md (Lean orchestration rules)
├── SkillOrchestration_Matrix (Routing logic)
├── KnowledgeStructure (Templates & libraries)
│
├── [Project A]_marketing.md (ICP, messaging, channels)
├── [Project B]_marketing.md
└── [Project C]_marketing.md

All projects → Share the same 25+ marketing skills
All skills → Reference the same templates + libraries
All campaigns → Report to shared metrics + learnings
```

---

## Support & Resources

**If stuck:**
- Reference the **MARKETING_OS_Instructions.md** (detailed behavioral rules)
- Check **MARKETING_OS_KnowledgeStructure.md** (templates)
- Review **MARKETING_OS_SkillOrchestration_Matrix.md** (which skill for what?)
- Check **MARKETING_OS_TokenOptimization_v1.0.md** (budgets)
- Look at **tasks.md** (known gaps + improvements)

**If you find a bug:**
- Document it in **tasks.md** under "Known Issues"
- Describe: What did you ask? What went wrong? What should happen?

**If you want to improve:**
- Add feature request to **tasks.md** under "Future Enhancements"

---

*Marketing OS v1.0 · Setup Guide · 2026-04-07*
*Everything you need to activate and use the system.*
